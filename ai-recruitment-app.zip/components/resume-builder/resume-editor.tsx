"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Plus, Trash2 } from "lucide-react"

interface ResumeEditorProps {
  resumeData: any
  onPersonalInfoChange: (field: string, value: string) => void
  onExperienceChange: (index: number, field: string, value: string) => void
  onEducationChange: (index: number, field: string, value: string) => void
  onAddExperience: () => void
  onAddEducation: () => void
  onRemoveExperience: (index: number) => void
  onRemoveEducation: (index: number) => void
  onAddSkill: () => void
  onRemoveSkill: (index: number) => void
  currentSkill: string
  onCurrentSkillChange: (skill: string) => void
}

export default function ResumeEditor(props: ResumeEditorProps) {
  return (
    <div className="space-y-6">
      {/* Personal Information */}
      <Card className="p-6 space-y-4">
        <h2 className="text-2xl font-bold">Personal Information</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <Input
            placeholder="Full Name"
            value={props.resumeData.personalInfo.fullName}
            onChange={(e) => props.onPersonalInfoChange("fullName", e.target.value)}
          />
          <Input
            placeholder="Email"
            type="email"
            value={props.resumeData.personalInfo.email}
            onChange={(e) => props.onPersonalInfoChange("email", e.target.value)}
          />
          <Input
            placeholder="Phone"
            value={props.resumeData.personalInfo.phone}
            onChange={(e) => props.onPersonalInfoChange("phone", e.target.value)}
          />
          <Input
            placeholder="Location"
            value={props.resumeData.personalInfo.location}
            onChange={(e) => props.onPersonalInfoChange("location", e.target.value)}
          />
        </div>
        <textarea
          className="w-full border border-border rounded-lg p-3 bg-background text-foreground"
          placeholder="Professional Summary"
          rows={4}
          value={props.resumeData.personalInfo.summary}
          onChange={(e) => props.onPersonalInfoChange("summary", e.target.value)}
        />
      </Card>

      {/* Experience */}
      <Card className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Experience</h2>
          <Button onClick={props.onAddExperience} className="gap-2 bg-transparent" variant="outline">
            <Plus className="w-4 h-4" />
            Add Experience
          </Button>
        </div>
        <div className="space-y-6">
          {props.resumeData.experience.map((exp: any, index: number) => (
            <div key={index} className="border border-border rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <h3 className="font-semibold">Experience {index + 1}</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => props.onRemoveExperience(index)}
                  className="text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <Input
                  placeholder="Company"
                  value={exp.company}
                  onChange={(e) => props.onExperienceChange(index, "company", e.target.value)}
                />
                <Input
                  placeholder="Position"
                  value={exp.position}
                  onChange={(e) => props.onExperienceChange(index, "position", e.target.value)}
                />
                <Input
                  placeholder="Start Date"
                  type="month"
                  value={exp.startDate}
                  onChange={(e) => props.onExperienceChange(index, "startDate", e.target.value)}
                />
                <Input
                  placeholder="End Date"
                  type="month"
                  value={exp.endDate}
                  onChange={(e) => props.onExperienceChange(index, "endDate", e.target.value)}
                />
              </div>
              <textarea
                className="w-full border border-border rounded-lg p-3 bg-background text-foreground"
                placeholder="Job Description"
                rows={3}
                value={exp.description}
                onChange={(e) => props.onExperienceChange(index, "description", e.target.value)}
              />
            </div>
          ))}
        </div>
      </Card>

      {/* Education */}
      <Card className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Education</h2>
          <Button onClick={props.onAddEducation} className="gap-2 bg-transparent" variant="outline">
            <Plus className="w-4 h-4" />
            Add Education
          </Button>
        </div>
        <div className="space-y-6">
          {props.resumeData.education.map((edu: any, index: number) => (
            <div key={index} className="border border-border rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <h3 className="font-semibold">Education {index + 1}</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => props.onRemoveEducation(index)}
                  className="text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <Input
                  placeholder="School/University"
                  value={edu.school}
                  onChange={(e) => props.onEducationChange(index, "school", e.target.value)}
                />
                <Input
                  placeholder="Degree"
                  value={edu.degree}
                  onChange={(e) => props.onEducationChange(index, "degree", e.target.value)}
                />
                <Input
                  placeholder="Field of Study"
                  value={edu.field}
                  onChange={(e) => props.onEducationChange(index, "field", e.target.value)}
                />
                <Input
                  placeholder="Graduation Year"
                  type="number"
                  value={edu.graduationYear}
                  onChange={(e) => props.onEducationChange(index, "graduationYear", e.target.value)}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Skills */}
      <Card className="p-6 space-y-4">
        <h2 className="text-2xl font-bold">Skills</h2>
        <div className="flex gap-2">
          <Input
            placeholder="Add a skill"
            value={props.currentSkill}
            onChange={(e) => props.onCurrentSkillChange(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && props.onAddSkill()}
          />
          <Button onClick={props.onAddSkill} className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Plus className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {props.resumeData.skills.map((skill: string, index: number) => (
            <div key={index} className="bg-accent/20 text-accent px-3 py-1 rounded-full flex items-center gap-2">
              {skill}
              <button onClick={() => props.onRemoveSkill(index)} className="hover:text-accent/70">
                ×
              </button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
