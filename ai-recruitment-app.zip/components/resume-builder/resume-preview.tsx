export default function ResumePreview({ resumeData }: any) {
  return (
    <div className="font-serif text-xs leading-relaxed">
      {/* Header */}
      <div className="mb-4 border-b pb-3 border-gray-300">
        <h1 className="text-2xl font-bold text-center">{resumeData.personalInfo.fullName || "Your Name"}</h1>
        <div className="flex justify-center gap-4 text-xs mt-2">
          {resumeData.personalInfo.email && <span>{resumeData.personalInfo.email}</span>}
          {resumeData.personalInfo.phone && <span>•</span>}
          {resumeData.personalInfo.phone && <span>{resumeData.personalInfo.phone}</span>}
          {resumeData.personalInfo.location && <span>•</span>}
          {resumeData.personalInfo.location && <span>{resumeData.personalInfo.location}</span>}
        </div>
      </div>

      {/* Summary */}
      {resumeData.personalInfo.summary && (
        <div className="mb-3">
          <h2 className="text-sm font-bold uppercase tracking-wide mb-1">Professional Summary</h2>
          <p className="text-xs leading-relaxed">{resumeData.personalInfo.summary}</p>
        </div>
      )}

      {/* Experience */}
      {resumeData.experience.some((exp: any) => exp.company) && (
        <div className="mb-3">
          <h2 className="text-sm font-bold uppercase tracking-wide mb-1">Experience</h2>
          <div className="space-y-2">
            {resumeData.experience.map(
              (exp: any, index: number) =>
                exp.company && (
                  <div key={index}>
                    <div className="flex justify-between">
                      <div className="font-semibold">{exp.position}</div>
                      {exp.startDate && (
                        <div className="text-xs">
                          {exp.startDate} - {exp.endDate || "Present"}
                        </div>
                      )}
                    </div>
                    <div className="text-xs italic">{exp.company}</div>
                    {exp.description && <p className="text-xs mt-1 whitespace-pre-wrap">{exp.description}</p>}
                  </div>
                ),
            )}
          </div>
        </div>
      )}

      {/* Education */}
      {resumeData.education.some((edu: any) => edu.school) && (
        <div className="mb-3">
          <h2 className="text-sm font-bold uppercase tracking-wide mb-1">Education</h2>
          <div className="space-y-2">
            {resumeData.education.map(
              (edu: any, index: number) =>
                edu.school && (
                  <div key={index}>
                    <div className="flex justify-between">
                      <div className="font-semibold">
                        {edu.degree} in {edu.field}
                      </div>
                      {edu.graduationYear && <div className="text-xs">{edu.graduationYear}</div>}
                    </div>
                    <div className="text-xs italic">{edu.school}</div>
                  </div>
                ),
            )}
          </div>
        </div>
      )}

      {/* Skills */}
      {resumeData.skills.length > 0 && (
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wide mb-1">Skills</h2>
          <p className="text-xs">{resumeData.skills.join(" • ")}</p>
        </div>
      )}
    </div>
  )
}
