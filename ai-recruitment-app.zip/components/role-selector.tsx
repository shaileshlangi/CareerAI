"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Building2, Users, FileText } from "lucide-react"
import Link from "next/link"

export default function RoleSelector() {
  const roles = [
    { id: "job-seeker", name: "Job Seeker", icon: FileText, color: "emerald" },
    { id: "employer", name: "Employer", icon: Building2, color: "orange" },
    { id: "recruiter", name: "Recruiter", icon: Users, color: "violet" },
    { id: "university", name: "University", icon: BookOpen, color: "blue" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary/5 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-2">Select Your Role</h1>
          <p className="text-muted-foreground">Choose the dashboard that fits your needs</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {roles.map((role) => {
            const Icon = role.icon
            return (
              <Link key={role.id} href={`/dashboard/${role.id}`}>
                <Card className="p-8 hover:shadow-xl hover:scale-105 transition-all cursor-pointer text-center">
                  <div
                    className={`w-16 h-16 bg-gradient-to-br from-${role.color}-400 to-${role.color}-600 rounded-xl flex items-center justify-center mx-auto mb-4`}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{role.name}</h3>
                  <Button className="w-full mt-4">Select Role</Button>
                </Card>
              </Link>
            )
          })}
        </div>
      </div>
    </div>
  )
}
