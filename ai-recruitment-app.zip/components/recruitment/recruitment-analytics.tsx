import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface RecruitmentAnalyticsProps {
  candidates: any[]
  jobs: any[]
}

export default function RecruitmentAnalytics({ candidates, jobs }: RecruitmentAnalyticsProps) {
  // Status distribution
  const statusData = [
    { name: "Interview Scheduled", value: candidates.filter((c) => c.status === "Interview Scheduled").length },
    { name: "Under Review", value: candidates.filter((c) => c.status === "Under Review").length },
    { name: "Screening", value: candidates.filter((c) => c.status === "Screening").length },
    { name: "Rejected", value: candidates.filter((c) => c.status === "Rejected").length },
  ]

  // Hiring timeline
  const timelineData = [
    { week: "Week 1", applications: 12, interviews: 3, offers: 1 },
    { week: "Week 2", applications: 18, interviews: 5, offers: 2 },
    { week: "Week 3", applications: 15, interviews: 4, offers: 1 },
    { week: "Week 4", applications: 24, interviews: 8, offers: 3 },
  ]

  const COLORS = ["#06b6d4", "#f97316", "#3b82f6", "#ef4444"]

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        {/* Candidate Status Distribution */}
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Candidate Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* Job Postings Overview */}
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Open Positions</h3>
          <div className="space-y-4">
            {jobs.map((job) => (
              <div key={job.id} className="border-b pb-4 last:border-b-0">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold">{job.title}</p>
                    <p className="text-xs text-muted-foreground">{job.location}</p>
                  </div>
                  <p className="text-lg font-bold text-accent">{job.applicants}</p>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-accent h-2 rounded-full"
                    style={{ width: `${(job.applicants / 40) * 100}%` }}
                  ></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">applicants</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Hiring Pipeline */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Hiring Pipeline</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={timelineData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="week" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="applications" fill="#06b6d4" />
            <Bar dataKey="interviews" fill="#f97316" />
            <Bar dataKey="offers" fill="#10b981" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Time-to-Hire Metrics */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4 text-center">
          <p className="text-sm text-muted-foreground mb-1">Avg Time to Hire</p>
          <p className="text-3xl font-bold text-accent">18 days</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-sm text-muted-foreground mb-1">Offer Acceptance Rate</p>
          <p className="text-3xl font-bold text-accent">82%</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-sm text-muted-foreground mb-1">Quality of Hire</p>
          <p className="text-3xl font-bold text-accent">4.2/5</p>
        </Card>
      </div>
    </div>
  )
}
