import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MoreVertical, Download, MessageSquare, CheckCircle2, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface Candidate {
  id: number
  name: string
  position: string
  email: string
  status: string
  rating: number
  appliedDate: string
  resumeScore: number
}

interface CandidateListProps {
  candidates: Candidate[]
}

export default function CandidateList({ candidates }: CandidateListProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Interview Scheduled":
        return <CheckCircle2 className="w-4 h-4 text-accent" />
      case "Under Review":
        return <Clock className="w-4 h-4 text-yellow-500" />
      case "Screening":
        return <Clock className="w-4 h-4 text-blue-500" />
      case "Rejected":
        return <XCircle className="w-4 h-4 text-destructive" />
      default:
        return null
    }
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "Interview Scheduled":
        return "bg-accent/20 text-accent border-accent/30"
      case "Under Review":
        return "bg-yellow-500/20 text-yellow-700 border-yellow-500/30"
      case "Screening":
        return "bg-blue-500/20 text-blue-700 border-blue-500/30"
      case "Rejected":
        return "bg-destructive/20 text-destructive border-destructive/30"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="space-y-3">
      {candidates.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No candidates found</p>
        </Card>
      ) : (
        candidates.map((candidate) => (
          <Card key={candidate.id} className="p-6 hover:border-accent/50 transition">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <div>
                    <h3 className="font-bold text-lg">{candidate.name}</h3>
                    <p className="text-sm text-muted-foreground">{candidate.position}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 items-center mt-3">
                  <Badge className={`${getStatusBadgeVariant(candidate.status)} border`}>{candidate.status}</Badge>
                  <div className="flex items-center gap-1 bg-accent/10 text-accent px-2 py-1 rounded text-xs">
                    <span>ATS Score: {candidate.resumeScore}%</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Applied: {new Date(candidate.appliedDate).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div className="flex gap-2 md:flex-col lg:flex-row">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Resume</span>
                </Button>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <MessageSquare className="w-4 h-4" />
                  <span className="hidden sm:inline">Message</span>
                </Button>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  )
}

import { XCircle } from "lucide-react"
