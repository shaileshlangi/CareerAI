import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MoreVertical, Users, MapPin, Clock } from "lucide-react"

interface Job {
  id: number
  title: string
  department: string
  location: string
  type: string
  posted: string
  applicants: number
  status: string
}

interface JobPostingsProps {
  jobs: Job[]
}

export default function JobPostings({ jobs }: JobPostingsProps) {
  return (
    <div className="space-y-4">
      {jobs.map((job) => (
        <Card key={job.id} className="p-6 hover:border-accent/50 transition">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
            <div className="flex-1">
              <div className="mb-3">
                <h3 className="text-xl font-bold mb-1">{job.title}</h3>
                <p className="text-sm text-muted-foreground">{job.department}</p>
              </div>

              <div className="flex flex-wrap gap-3 mb-4 text-sm">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  {job.location}
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  {job.type}
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Users className="w-4 h-4" />
                  {job.applicants} applicants
                </div>
              </div>

              <div className="flex gap-2 items-center">
                <Badge variant="outline" className="bg-accent/10 text-accent border-accent/30">
                  {job.status}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  Posted: {new Date(job.posted).toLocaleDateString()}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                View Applications
              </Button>
              <Button variant="outline" size="sm">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
