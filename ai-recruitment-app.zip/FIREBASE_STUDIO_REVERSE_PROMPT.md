# TalentFlow AI Recruitment Platform - Complete Design Specification

## Overview
This document provides a detailed reverse prompt for recreating the TalentFlow AI Recruitment Platform in Firebase Studio. It includes all pages, components, layouts, color schemes, animations, and interactive elements.

---

## COLOR PALETTE & DESIGN SYSTEM

### Primary Colors
- **Primary (Vibrant Purple)**: oklch(0.58 0.25 290) - Main brand color
- **Secondary (Hot Pink)**: oklch(0.65 0.22 330) - Accent color
- **Accent (Bright Cyan/Blue)**: oklch(0.65 0.22 260) - Highlight color

### Background & Text
- **Background**: oklch(0.98 0 0) - Light mode white
- **Background Dark**: oklch(0.09 0 0) - Dark mode black
- **Foreground**: oklch(0.145 0 0) - Text dark
- **Foreground Dark**: oklch(0.98 0 0) - Text light
- **Muted Foreground**: oklch(0.556 0 0)

### Additional Colors
- **Card**: oklch(1 0 0) white / oklch(0.12 0 0) dark
- **Border**: oklch(0.92 0 0) light / oklch(0.2 0 0) dark
- **Input**: oklch(0.96 0 0)

### Gradient Colors Used
- Emerald-Teal: from-emerald-400 to-teal-600
- Cyan-Blue: from-cyan-400 to-blue-600
- Purple-Indigo: from-purple-400 to-indigo-600
- Orange-Rose: from-orange-400 to-rose-600
- Pink-Red: from-pink-400 to-red-600
- Yellow-Orange: from-yellow-400 to-orange-600
- Green-Emerald: from-green-400 to-emerald-600

---

## TYPOGRAPHY

### Fonts
- **Sans-serif (Primary)**: Geist Font Family
- **Monospace**: Geist Mono Font Family

### Font Sizes & Hierarchy
- **Heading 1 (H1)**: text-5xl to text-6xl (48-72px) - Bold weight
- **Heading 2 (H2)**: text-4xl to text-5xl (36-60px) - Bold
- **Heading 3 (H3)**: text-2xl to text-3xl (28-36px) - Bold
- **Body Text**: text-lg to text-xl (18-20px) - Regular
- **Small Text**: text-sm (14px)
- **Extra Small**: text-xs (12px)

### Line Heights
- **Body**: leading-relaxed (1.6)
- **Headings**: leading-tight (1.2-1.4)

---

## SPACING & LAYOUT

### Padding/Margins (Tailwind scale)
- Container max-width: max-w-7xl (1280px)
- Section padding: py-20 md:py-32 (80px-128px)
- Card padding: p-6 to p-8 (24px-32px)
- Gap between columns: gap-8 to gap-12 (32px-48px)

### Layout Patterns
- Max content width: max-w-7xl
- Mobile padding: px-4 sm:px-6 lg:px-8
- Grid: 2-3 columns on desktop, 1 on mobile (md:grid-cols-2, md:grid-cols-3)

---

## ANIMATIONS & INTERACTIONS

### Keyframe Animations
1. **float-up**: Vertical movement with opacity fade-in (0.6s ease-out)
2. **gradient-shift**: Background position shift (3s infinite)
3. **glow**: Shadow box-glow pulse effect (2s ease-in-out)
4. **pulse-scale**: Scale transformation (2s ease-in-out)
5. **scroll**: Infinite horizontal scroll for company logos (30s linear)

### Interaction Effects
- **Hover Scale**: scale-105 (5% increase)
- **Smooth Transitions**: transition-all duration-300
- **Border Color Transitions**: hover:border-accent, hover:border-primary/50
- **Shadow Effects**: hover:shadow-2xl, shadow-lg, shadow-xl

### Button States
- Default: shadow-lg with gradient background
- Hover: opacity-90 with scale transform
- Active: Gradient border with color fill

---

## PAGE STRUCTURE & COMPONENTS

### PAGE 1: HOMEPAGE (/)

#### Section 1: Hero Section
- **Layout**: 2-column grid (md:grid-cols-2)
- **Left Column**:
  - H1: "Land Your Dream Job with AI"
  - Body text with value proposition
  - Gradient text (from-primary via-secondary to-accent)
  - Two CTA buttons: "Explore Features" (gradient primary), "Watch Demo" (outline)
  - Stats bar with 3 metrics: "1M+ Users", "95% Success Rate", "14 Countries"
  
- **Right Column**:
  - Professional image: person holding resume (professional-person-holding-resume-document-confid.jpg)
  - Image hover effect: scale-105 transition
  - Border-radius: rounded-2xl
  - Shadow: shadow-2xl

#### Section 2: Templates & Build Your Resume
- **Layout**: 2-column grid reversed (md:grid-cols-2)
- **Left Image**:
  - Image: resume-templates-showcase-different-layouts.jpg
  - Rounded-2xl border, shadow-2xl, hover scale effect
  
- **Right Content**:
  - H2: "20+ Professional Templates" (gradient text secondary to rose)
  - Feature list (5 items):
    - 20+ industry-specific designs
    - Real-time preview editor
    - ATS-optimized formatting
    - Export as PDF instantly
    - One-click customization
  - Each feature: CheckCircle2 icon with gradient background
  - CTA Button: "Start Building Now"

#### Section 3: Our Complete Product Suite
- **Layout**: 3-column grid (md:grid-cols-3)
- **6 Product Cards** (each with):
  - Gradient colored icon (14h x 14w)
  - Title, Description
  - 4 feature dots
  - "Learn More" outline button
  - Hover effects: scale-105, shadow-2xl, border color change

Products:
  1. Resume Builder - Emerald-Teal gradient
  2. Interview Coach - Purple-Violet gradient
  3. Career Planner - Orange-Amber gradient
  4. Resume Optimizer - Cyan-Blue gradient
  5. Cover Letter Pro - Pink-Rose gradient
  6. Goal Achievement - Indigo-Purple gradient

#### Section 4: One Professional, Multiple Resumes
- **Layout**: Image with overlay text
- **Image**: person-with-multiple-different-resume-versions-for.jpg
- **Overlay**: Gradient to-black/60 top-to-bottom
- **Text overlay**: "Adapt Your Resume for Every Role" with subtext
- **4-Step Breakdown** (below image):
  - 4-column grid
  - Each step: Number circle, Title, Description
  - Numbers in gradient background circles

#### Section 5: Get Hired at Leading Companies
- **Background**: Gradient from secondary/10 to accent/10
- **Content**:
  - H2: "Get Hired at Leading Companies"
  - Fortune 50 company logos in infinite scroll animation
  - Company names displayed in cards with border, hover effects
  - Animation: scroll 30s linear infinite

#### Section 6: Master Each Feature (7 Deep-Dives)
- **Layout**: Alternating 2-column grid (each feature)
- **Each Feature Card**:
  - Image on left/right alternating
  - Icon + Title + Description
  - 4 detail bullet points
  - CTA button with feature-specific gradient
  - Image with border gradient

Features:
  1. AI Resume Builder - Emerald-Teal
  2. AI Resume Optimizer - Cyan-Blue
  3. AI Cover Letter - Purple-Indigo
  4. AI Interview Prep - Pink-Red
  5. AI Career Planning - Yellow-Orange
  6. AI Goal Setting - Green-Emerald
  7. (Note: Job Assistant shown separately)

#### Section 7: Ready to Transform Your Career? (CTA)
- **Background**: Gradient from secondary to primary to accent
- **Text**: White color
- **Icon**: Lightbulb with bounce animation
- **Layout**: Text center aligned
- **Button**: White background, primary text color
- **Height**: Reduced (12-16 padding)

#### Section 8: Countries Worldwide
- **Background**: Subtle gradient
- **Layout**: 7-column grid (compact)
- **Country Cards**: Each country as clickable link
- **Size**: Smaller than previous sections

#### Section 9: Testimonials/Reviews
- **Creative Display**: Gradient colored cards
- **Layout**: Grid with alternating colors
- **Each Card**:
  - User name, avatar placeholder
  - Star rating
  - Review text
  - Gradient background (different for each)

#### Section 10: Footer
- **Background**: Dark gradient
- **Columns**: 4-5 sections
  - Product links
  - Company links
  - Resources links
  - Legal links
  - Social icons
- **Bottom**: Copyright and additional links

---

### PAGE 2: ABOUT (/about)

#### Navigation
- Sticky top navbar
- TalentFlow logo with gradient
- Links: About, Product, Pricing, Contact
- Sign In button (gradient)

#### Hero Section
- H1: "About [TalentFlow]" (gradient text)
- Subtext: Company description

#### Mission Section
- 2-column layout
- Left: Mission text with 3 feature items (CheckCircle icons with different colors)
- Right: Gradient placeholder box with emoji

#### Stats Section
- 4-column grid
- Each stat card: Icon, Value, Label
- Border with hover effect

#### Team Section
- H2: Team title
- Description paragraph

#### CTA Section
- Gradient background box
- Button with ArrowRight icon

---

### PAGE 3: PRODUCT (/product)

Similar structure to About but focusing on product features:
- Feature showcase cards
- Product comparisons
- Detailed descriptions
- Multiple CTA points

---

### PAGE 4: PRICING (/pricing)

#### Pricing Plans (3 tiers)
1. **Starter**
   - Price: $0 (forever free)
   - 5 features listed
   - Default styling

2. **Professional** (Highlighted)
   - Price: $9.99/month
   - 7 features listed
   - Scale: scale-105
   - Border: primary color
   - Background gradient
   - Shadow: shadow-xl

3. **Enterprise**
   - Price: Custom
   - 6 features listed
   - Default styling

#### FAQ Section
- 4-column grid (2x2)
- Each card: Question, Answer
- Border styling: border-border/50

#### CTA Section
- Gradient background
- "Start your free journey today"

---

### PAGE 5: CONTACT (/contact)

- Contact form with fields:
  - Name
  - Email
  - Subject
  - Message
- Submit button
- Company contact info
- Map placeholder
- Social links

---

## AUTHENTICATION PAGES

### SIGNUP (/auth/signup)

#### Layout
- Center screen, full height
- Max width: max-w-2xl
- Dark gradient background

#### Step 1: Role Selection
- TalentFlow logo (gradient)
- H1: "Choose Your Role"
- 4 role cards in 2x2 grid:
  1. Job Seeker (Briefcase icon) - Emerald gradient
  2. Employer (Building2 icon) - Cyan gradient
  3. Recruiter (Users icon) - Purple gradient
  4. University (BookOpen icon) - Orange gradient

- Each card:
  - Icon
  - Title
  - Description
  - Border: 2px, hover primary/50
  - Cursor: pointer
  - Hover scale: scale-105

- Continue button (disabled until role selected)
- Link to Sign In

#### Step 2: Account Creation
- Back button
- Role title display
- Form fields:
  - Full Name (text input)
  - Email Address (email input)
  - Phone Number (tel input)
  - Conditional fields based on role:
    - Employer: Company Name
    - Recruiter: Recruitment Firm
    - University: University Name
  - Password (password input)
  - Confirm Password (password input)
- Security info box (bg-primary/10, border-primary/20)
- Create Account button
- Sign In link

#### Styling
- Input fields: w-full, p-3, rounded-lg
- Labels: text-sm font-medium
- Form labels: Gray color
- Card background: White/Dark theme compatible
- All buttons: Gradient primary to secondary

---

### SIGNIN (/auth/signin)

#### Layout
- Similar to signup, centered
- Max width: max-w-md

#### Form Sections
- Logo with gradient
- H1: "Welcome Back"
- Subtext: "Sign in to your account"

#### Form Fields
- Email (email input)
- Password (password input)
- "Forgot Password?" link

#### Additional Options
- "Remember me" checkbox
- Sign In button (gradient)
- "Don't have an account?" link to signup
- Social login options (Google, LinkedIn icons with text)

#### Role Selection (Optional)
- Radio buttons or dropdown for role selection
- Affects redirect after login

---

## DASHBOARDS

### JOB SEEKER DASHBOARD (/dashboard/job-seeker)

#### Header
- Sticky top navbar
- Title: "Job Seeker Dashboard"
- Subtext: "Accelerate your career with AI"
- User menu (top right)
- Border bottom

#### Quick Stats (3-column grid)
1. **Resume Score**
   - Icon: TrendingUp (Emerald)
   - Value: "85/100"
   - Subtext: "+5 points this week"
   - Background: Emerald gradient

2. **Applications**
   - Icon: Briefcase (Cyan)
   - Value: "12"
   - Subtext: "3 interviews scheduled"
   - Background: Cyan gradient

3. **Skills Level**
   - Icon: Sparkles (Purple)
   - Value: "Advanced"
   - Subtext: "7 skills improved"
   - Background: Purple gradient

#### AI-Powered Tools Section
- H2: "AI-Powered Tools"
- Subtext: "Use our 7 AI tools to advance your career"
- 3-column grid (md:grid-cols-3)

**7 Feature Cards** (each with):
- Gradient icon (12h x 12w)
- Title
- Description
- Active status badge (text-emerald-600)
- ArrowRight icon
- Hover effects: scale-105, shadow-2xl

Features:
  1. AI Resume Builder - Emerald-Teal
  2. AI Resume Optimizer - Cyan-Blue
  3. AI Cover Letter - Purple-Indigo
  4. AI Job Assistant - Orange-Rose
  5. AI Interview Prep - Pink-Red
  6. AI Career Planning - Yellow-Orange
  7. AI Goal Setting - Green-Emerald

#### Recent Activity & Recommendations Section (2-column grid)

**Left: Recent Activity**
- H3: "Recent Activity"
- 3 activity items:
  - CheckCircle2 icon (emerald)
  - Title
  - Time
  - Border between items

**Right: Recommended Next Steps**
- H3: "Recommended Next Steps"
- 3 buttons (gradient backgrounds, different colors)
- Icons with text

---

### EMPLOYER DASHBOARD (/dashboard/employer)

#### Similar Structure to Job Seeker
- Sticky header
- Different stats:
  - Active Job Postings
  - Total Candidates
  - Interviews Scheduled

#### Features
- Job Posting Manager
- Candidate Screening Tools
- Analytics Dashboard
- Team Management Section

---

### RECRUITER DASHBOARD (/dashboard/recruiter)

#### Recruiter-Specific Content
- Candidate Database
- Pipeline Management
- AI Matching Engine
- Performance Analytics
- Top Matches Display

---

### UNIVERSITY DASHBOARD (/dashboard/university)

#### University-Specific Content
- Student Profile Management
- Career Event Organization
- Dedicated Job Board
- Placement Analytics
- Upcoming Events Tracker

---

### ADMIN DASHBOARD (/dashboard/admin)

#### System Overview
- User Statistics
- Recent Signups Monitor
- System Health Monitoring
- Quick Action Buttons
- Performance Metrics

---

## COMPONENT SPECIFICATIONS

### Buttons
- Default: Rounded-lg, py-2 px-4
- Large: Rounded-lg, py-3 px-6, size-lg
- Outline: border-2, transparent background
- Gradient: bg-gradient-to-r from-X to-Y
- Hover: opacity-90, scale transitions

### Cards
- Border: border-2 (default border-border)
- Border-radius: rounded-2xl
- Padding: p-6 to p-8
- Hover: border-accent, shadow-2xl
- Background: bg-white/dark, transition on hover

### Input Fields
- Background: bg-input
- Border: border border-input
- Focus: ring-2 ring-ring
- Rounded: rounded-md
- Padding: p-2 to p-3

### Gradient Text
- Text: bg-gradient-to-r from-X via-Y to-Z
- Clip: bg-clip-text text-transparent

### Icons
- Sizes: w-4 h-4 (small), w-6 h-6 (medium), w-8 h-8 (large), w-12 h-12 (extra large)
- Colors: Applied via gradient backgrounds on containers
- Hover: Scale up or glow effect

---

## RESPONSIVE DESIGN

### Breakpoints (Tailwind)
- Mobile: < 768px (no prefix)
- Tablet: md: (≥ 768px)
- Desktop: lg: (≥ 1024px)
- Large: xl: (≥ 1280px)

### Mobile Adaptations
- Grid columns: 1 column (mobile), md:2-3 columns (desktop)
- Padding: px-4 (mobile), lg:px-8 (desktop)
- Font sizes: text-3xl (mobile), text-5xl (desktop) for headings
- Spacing: py-12 (mobile), py-20 md:py-32 (desktop)

---

## IMAGES USED

### Homepage Images
1. professional-person-holding-resume-document-confid.jpg (Hero)
2. resume-templates-showcase-different-layouts.jpg (Templates section)
3. person-with-multiple-different-resume-versions-for.jpg (Multi-resume section)
4. ai-job-assistant-smart-recommendations-interface.jpg (Job Assistant section)
5. Feature images (generated for each AI feature deep-dive)

### Image Styling
- Border-radius: rounded-2xl
- Shadow: shadow-2xl
- Hover effect: scale-105 transition-transform duration-300
- Object-fit: object-cover

---

## ANIMATIONS SUMMARY

| Animation | Duration | Easing | Trigger |
|-----------|----------|--------|---------|
| float-up | 0.6s | ease-out | Page load |
| gradient-shift | 3s | ease | Infinite |
| glow | 2s | ease-in-out | Infinite |
| pulse-scale | 2s | ease-in-out | Infinite |
| scroll | 30s | linear | Infinite |
| scale-105 | 0.3s | ease | Hover |

---

## DARK MODE SUPPORT

All sections support dark mode with automatic color adjustments:
- Background transitions from white to dark
- Text transitions from dark to light
- Cards adapt with dark theme colors
- Border colors adjust for visibility
- All gradients maintain contrast

---

## ACCESSIBILITY FEATURES

- Alt text on all images
- Semantic HTML (main, nav, section, header, footer)
- ARIA roles on interactive elements
- Color contrast meets WCAG standards
- Focus states on buttons and inputs
- Screen reader only text (sr-only class)
- Keyboard navigation support

---

## PERFORMANCE OPTIMIZATIONS

- Lazy loading for images
- Smooth animations with GPU acceleration
- Optimized border-radius and shadows
- Reduced motion support for animations
- Efficient grid layouts
- No unnecessary renders

---

## NAVIGATION STRUCTURE

\`\`\`
/                    - Homepage
/about               - About page
/product             - Product page
/pricing             - Pricing page
/contact             - Contact page
/auth/signup         - Signup form (multi-step)
/auth/signin         - Signin form
/dashboard/job-seeker    - Job seeker dashboard
/dashboard/employer      - Employer dashboard
/dashboard/recruiter     - Recruiter dashboard
/dashboard/university    - University dashboard
/dashboard/admin         - Admin dashboard
\`\`\`

---

## TECHNOLOGY STACK (Firebase Studio)

- **Framework**: React with Tailwind CSS v4
- **Color System**: CSS Custom Properties (oklch format)
- **Animations**: CSS Keyframes
- **Responsive**: Tailwind responsive classes
- **State Management**: React hooks
- **Icons**: Lucide React Icons
- **Forms**: React state management

---

## NOTES FOR FIREBASE STUDIO RECREATION

1. Use exact Tailwind class names provided (no alternatives)
2. Maintain color palette consistency across all pages
3. Implement all hover and transition effects
4. Ensure responsive design matches all breakpoints
5. Use semantic HTML structure
6. Implement proper accessibility features
7. Include all animation effects with correct timing
8. Test dark mode functionality
9. Verify gradient text rendering
10. Ensure form validation and state management
