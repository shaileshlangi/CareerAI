export async function analyzeResume(resumeContent: string, jobDescription?: string) {
  const response = await fetch("/api/ai/analyze-resume", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ resumeContent, jobDescription }),
  })
  return response.json()
}

export async function generateJobDescription(
  jobTitle: string,
  department?: string,
  requirements?: string,
  responsibilities?: string,
) {
  const response = await fetch("/api/ai/generate-job-description", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jobTitle, department, requirements, responsibilities }),
  })
  return response.json()
}

export async function screenCandidates(candidates: any[], jobRequirements?: string) {
  const response = await fetch("/api/ai/screen-candidates", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ candidates, jobRequirements }),
  })
  return response.json()
}

export async function generateInterviewQuestions(
  position: string,
  level?: string,
  skills?: string,
  companyInfo?: string,
) {
  const response = await fetch("/api/ai/generate-interview-questions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ position, level, skills, companyInfo }),
  })
  return response.json()
}

export async function improveResume(resumeContent: string, improvements?: string) {
  const response = await fetch("/api/ai/improve-resume", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ resumeContent, improvements }),
  })
  return response.json()
}
