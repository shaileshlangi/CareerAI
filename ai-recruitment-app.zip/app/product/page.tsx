"use client"

import Link from "next/link"
import { ArrowRight, Sparkles, FileText, Brain, Users, Target, BarChart3 } from "lucide-react"

export default function ProductPage() {
  const features = [
    {
      icon: FileText,
      title: "AI Resume Builder",
      description: "Create professional, ATS-optimized resumes with AI assistance",
    },
    {
      icon: Sparkles,
      title: "Resume Optimizer",
      description: "Get real-time feedback and improve your resume score",
    },
    {
      icon: Brain,
      title: "Cover Letter Generator",
      description: "Generate tailored cover letters for each application",
    },
    {
      icon: Users,
      title: "Interview Preparation",
      description: "Practice with AI coaching and get interview tips",
    },
    {
      icon: Target,
      title: "Career Planning",
      description: "Personalized career roadmap and skill development",
    },
    {
      icon: BarChart3,
      title: "Job Matching",
      description: "Find jobs that match your skills and goals",
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border/50 backdrop-blur-md bg-background/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            TalentFlow
          </div>
          <div className="flex gap-8">
            <Link href="/about" className="text-muted-foreground hover:text-foreground">
              About
            </Link>
            <Link href="/product" className="text-foreground font-medium">
              Product
            </Link>
            <Link href="/pricing" className="text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground">
              Contact
            </Link>
          </div>
          <Link
            href="/auth/signin"
            className="px-6 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Sign In
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h1 className="text-5xl font-bold text-foreground mb-6">
          Complete AI Suite for{" "}
          <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            Career Success
          </span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Everything you need to land your dream job with AI-powered tools and expert insights
        </p>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <div
              key={i}
              className="p-6 rounded-xl border border-border/50 bg-card hover:border-primary/50 hover:shadow-lg transition hover:scale-105"
            >
              <feature.icon className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Detailed Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="space-y-16">
          {[
            {
              title: "AI Resume Builder",
              desc: "Build professional resumes with AI suggestions. Choose from 20+ templates and get instant feedback.",
            },
            {
              title: "Smart Job Matching",
              desc: "AI algorithms match you with positions based on your skills, experience, and career goals.",
            },
            {
              title: "Career Planning Tools",
              desc: "Set achievable goals, track progress, and get personalized development recommendations.",
            },
          ].map((item, i) => (
            <div
              key={i}
              className={`grid md:grid-cols-2 gap-8 items-center ${i % 2 === 1 ? "md:flex-row-reverse" : ""}`}
            >
              <div>
                <h3 className="text-3xl font-bold text-foreground mb-4">{item.title}</h3>
                <p className="text-lg text-muted-foreground">{item.desc}</p>
              </div>
              <div className="h-64 bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 rounded-xl border border-border/50" />
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mb-8">
        <div className="p-12 rounded-2xl bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 border border-border text-center space-y-6">
          <h3 className="text-3xl font-bold text-foreground">Start building your perfect career today</h3>
          <Link
            href="/auth/signup"
            className="inline-flex items-center gap-2 px-8 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Get Started Free <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </main>
  )
}
