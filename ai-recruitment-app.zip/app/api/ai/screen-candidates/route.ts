import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { candidates, jobRequirements } = await req.json()

    if (!candidates || candidates.length === 0) {
      return Response.json({ error: "Candidates array is required" }, { status: 400 })
    }

    const candidatesText = candidates
      .map((c: any, i: number) => `Candidate ${i + 1}:\nName: ${c.name}\nResume: ${c.resume}\n`)
      .join("\n")

    const { text: screening } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `You are an expert recruiter. Screen the following candidates against the job requirements.

Job Requirements:
${jobRequirements || "Senior role with relevant experience"}

${candidatesText}

For each candidate, provide:
1. Match Score (0-100)
2. Key Strengths for this role
3. Potential Concerns
4. Recommendation (Strong Yes / Yes / Maybe / No)
5. Suggested Interview Questions

Format as JSON with candidate results.`,
    })

    return Response.json({
      screeningResults: JSON.parse(screening),
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Candidate screening error:", error)
    return Response.json({ error: "Failed to screen candidates" }, { status: 500 })
  }
}
