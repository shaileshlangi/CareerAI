import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { jobTitle, department, requirements, responsibilities } = await req.json()

    if (!jobTitle) {
      return Response.json({ error: "Job title is required" }, { status: 400 })
    }

    const { text: jobDescription } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `You are an expert HR professional specializing in creating compelling job descriptions.

Job Title: ${jobTitle}
Department: ${department || "Not specified"}
${requirements ? `Key Requirements:\n${requirements}` : ""}
${responsibilities ? `Main Responsibilities:\n${responsibilities}` : ""}

Please generate a professional and comprehensive job description that includes:
1. Job Overview
2. Key Responsibilities
3. Required Qualifications
4. Preferred Qualifications
5. Benefits & Compensation (generic overview)
6. Company Culture Highlights
7. Application Call-to-Action

Make it engaging, clear, and optimized for attracting top talent. Format the response as a well-structured job posting.`,
    })

    return Response.json({
      jobDescription,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Job description generation error:", error)
    return Response.json({ error: "Failed to generate job description" }, { status: 500 })
  }
}
