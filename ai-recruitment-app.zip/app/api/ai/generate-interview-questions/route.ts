import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { position, level, skills, companyInfo } = await req.json()

    if (!position) {
      return Response.json({ error: "Position is required" }, { status: 400 })
    }

    const { text: questions } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `Generate comprehensive interview questions for the following role:

Position: ${position}
Level: ${level || "Mid-level"}
${skills ? `Key Skills:\n${skills}` : ""}
${companyInfo ? `Company Context:\n${companyInfo}` : ""}

Please create:
1. 3-5 Behavioral Questions
2. 3-5 Technical/Role-Specific Questions
3. 2-3 Problem-Solving Scenarios
4. 2-3 Company Culture Fit Questions

For each question, provide:
- The question
- Why it's important
- What to listen for in the response
- Scoring guidelines

Format as JSON.`,
    })

    return Response.json({
      interviewQuestions: JSON.parse(questions),
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Interview questions generation error:", error)
    return Response.json({ error: "Failed to generate interview questions" }, { status: 500 })
  }
}
