import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { resumeContent, jobDescription } = await req.json()

    if (!resumeContent) {
      return Response.json({ error: "Resume content is required" }, { status: 400 })
    }

    const { text: analysis } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `You are an expert HR recruiter and resume analyst. 
      
Resume Content:
${resumeContent}

${jobDescription ? `Job Description:\n${jobDescription}` : "No specific job description provided."}

Please provide a detailed analysis including:
1. Resume Quality Score (0-100)
2. Key Strengths
3. Areas for Improvement
4. ATS Compatibility Assessment
5. Recommendations for Enhancement
${jobDescription ? "6. Job Match Score and Fit Analysis" : ""}

Format the response as JSON.`,
    })

    return Response.json({
      analysis: JSON.parse(analysis),
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Resume analysis error:", error)
    return Response.json({ error: "Failed to analyze resume" }, { status: 500 })
  }
}
