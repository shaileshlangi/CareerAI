import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { resumeContent, improvements } = await req.json()

    if (!resumeContent) {
      return Response.json({ error: "Resume content is required" }, { status: 400 })
    }

    const { text: suggestions } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `You are an expert resume writer and HR professional.

Current Resume:
${resumeContent}

Please provide detailed suggestions for improving this resume in ${improvements || "all"} areas:

1. Professional Summary - Make it compelling and achievement-focused
2. Experience Section - Improve with action verbs and quantifiable results
3. Skills Section - Prioritize and optimize for ATS
4. Formatting & Structure - Ensure readability and professional presentation
5. Keywords & Optimization - Suggest industry-relevant keywords

For each suggestion, provide:
- Current Issue
- Recommended Change
- Improved Example
- Impact on ATS/Recruiter Review

Format as JSON.`,
    })

    return Response.json({
      suggestions: JSON.parse(suggestions),
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Resume improvement error:", error)
    return Response.json({ error: "Failed to generate improvements" }, { status: 500 })
  }
}
