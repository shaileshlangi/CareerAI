"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Eye, Save } from "lucide-react"
import ResumeEditor from "@/components/resume-builder/resume-editor"
import ResumePreview from "@/components/resume-builder/resume-preview"

export default function ResumeBuilderPage() {
  const [resumeData, setResumeData] = useState({
    personalInfo: {
      fullName: "",
      email: "",
      phone: "",
      location: "",
      summary: "",
    },
    experience: [{ company: "", position: "", startDate: "", endDate: "", description: "" }],
    education: [{ school: "", degree: "", field: "", graduationYear: "" }],
    skills: [],
  })

  const [activeTab, setActiveTab] = useState("edit")
  const [currentSkill, setCurrentSkill] = useState("")

  const handlePersonalInfoChange = (field: string, value: string) => {
    setResumeData({
      ...resumeData,
      personalInfo: { ...resumeData.personalInfo, [field]: value },
    })
  }

  const handleExperienceChange = (index: number, field: string, value: string) => {
    const newExperience = [...resumeData.experience]
    newExperience[index] = { ...newExperience[index], [field]: value }
    setResumeData({ ...resumeData, experience: newExperience })
  }

  const handleEducationChange = (index: number, field: string, value: string) => {
    const newEducation = [...resumeData.education]
    newEducation[index] = { ...newEducation[index], [field]: value }
    setResumeData({ ...resumeData, education: newEducation })
  }

  const addExperience = () => {
    setResumeData({
      ...resumeData,
      experience: [
        ...resumeData.experience,
        { company: "", position: "", startDate: "", endDate: "", description: "" },
      ],
    })
  }

  const addEducation = () => {
    setResumeData({
      ...resumeData,
      education: [...resumeData.education, { school: "", degree: "", field: "", graduationYear: "" }],
    })
  }

  const addSkill = () => {
    if (currentSkill.trim()) {
      setResumeData({
        ...resumeData,
        skills: [...resumeData.skills, currentSkill],
      })
      setCurrentSkill("")
    }
  }

  const removeSkill = (index: number) => {
    setResumeData({
      ...resumeData,
      skills: resumeData.skills.filter((_, i) => i !== index),
    })
  }

  const removeExperience = (index: number) => {
    setResumeData({
      ...resumeData,
      experience: resumeData.experience.filter((_, i) => i !== index),
    })
  }

  const removeEducation = (index: number) => {
    setResumeData({
      ...resumeData,
      education: resumeData.education.filter((_, i) => i !== index),
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Resume Builder</h1>
          <div className="flex gap-3">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Save className="w-4 h-4" />
              Save Draft
            </Button>
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2">
              <Download className="w-4 h-4" />
              Download PDF
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Editor Panel */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="edit">Edit</TabsTrigger>
                <TabsTrigger value="preview">Preview</TabsTrigger>
                <TabsTrigger value="ai-help">AI Help</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
              </TabsList>

              <TabsContent value="edit" className="space-y-6 mt-6">
                <ResumeEditor
                  resumeData={resumeData}
                  onPersonalInfoChange={handlePersonalInfoChange}
                  onExperienceChange={handleExperienceChange}
                  onEducationChange={handleEducationChange}
                  onAddExperience={addExperience}
                  onAddEducation={addEducation}
                  onRemoveExperience={removeExperience}
                  onRemoveEducation={removeEducation}
                  onAddSkill={addSkill}
                  onRemoveSkill={removeSkill}
                  currentSkill={currentSkill}
                  onCurrentSkillChange={setCurrentSkill}
                />
              </TabsContent>

              <TabsContent value="preview" className="mt-6">
                <div className="bg-white text-black rounded-lg p-12 shadow-lg">
                  <ResumePreview resumeData={resumeData} />
                </div>
              </TabsContent>

              <TabsContent value="ai-help" className="mt-6">
                <Card className="p-6 space-y-4">
                  <h3 className="text-lg font-bold">AI Writing Assistant</h3>
                  <p className="text-muted-foreground">
                    Get AI-powered suggestions to improve your resume content, optimize for ATS, and highlight your
                    strengths.
                  </p>
                  <Button className="bg-accent hover:bg-accent/90 text-accent-foreground w-full">
                    Get AI Suggestions
                  </Button>
                </Card>
              </TabsContent>

              <TabsContent value="templates" className="mt-6">
                <Card className="p-6 space-y-4">
                  <h3 className="text-lg font-bold">Resume Templates</h3>
                  <p className="text-muted-foreground">
                    Choose from professionally designed templates to make your resume stand out.
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    {["Modern", "Classic", "Creative", "ATS-Optimized"].map((template) => (
                      <div
                        key={template}
                        className="border border-border rounded-lg p-4 text-center hover:bg-card cursor-pointer"
                      >
                        {template}
                      </div>
                    ))}
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Preview Panel */}
          <div className="hidden lg:block sticky top-24">
            <Card className="p-6 bg-white text-black">
              <h3 className="font-bold mb-4 flex items-center gap-2 text-black">
                <Eye className="w-4 h-4" />
                Preview
              </h3>
              <div className="border border-gray-200 rounded overflow-hidden">
                <ResumePreview resumeData={resumeData} />
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
