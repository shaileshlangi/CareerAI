"use client"

import Link from "next/link"
import { ArrowRight, CheckCircle, Users, Zap, Globe } from "lucide-react"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border/50 backdrop-blur-md bg-background/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            TalentFlow
          </div>
          <div className="flex gap-8">
            <Link href="/about" className="text-foreground font-medium">
              About
            </Link>
            <Link href="/product" className="text-muted-foreground hover:text-foreground">
              Product
            </Link>
            <Link href="/pricing" className="text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground">
              Contact
            </Link>
          </div>
          <Link
            href="/auth/signin"
            className="px-6 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Sign In
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-6">
          <h1 className="text-5xl font-bold text-foreground">
            About{" "}
            <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              TalentFlow
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Empowering job seekers and employers with AI-driven recruitment solutions
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-foreground">Our Mission</h2>
            <p className="text-lg text-muted-foreground">
              We believe that finding the right job or the right candidate shouldn't be complicated. TalentFlow uses
              cutting-edge AI technology to bridge the gap between talented professionals and amazing opportunities.
            </p>
            <div className="space-y-4">
              <div className="flex gap-4 items-start">
                <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground">AI-Powered Matching</h3>
                  <p className="text-muted-foreground">Advanced algorithms find the perfect fit</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <CheckCircle className="w-6 h-6 text-secondary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground">Time Efficiency</h3>
                  <p className="text-muted-foreground">Save hours on recruiting and job search</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground">Global Reach</h3>
                  <p className="text-muted-foreground">Available in 14 countries worldwide</p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative h-96 bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 rounded-2xl border border-border/50 overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-6xl">🎯</div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {[
            { icon: Users, label: "Active Users", value: "50K+" },
            { icon: Globe, label: "Countries", value: "14" },
            { icon: Zap, label: "Success Rate", value: "94%" },
            { icon: ArrowRight, label: "Placements", value: "10K+" },
          ].map((stat, i) => (
            <div key={i} className="p-6 rounded-xl border border-border/50 bg-card hover:border-primary/50 transition">
              <stat.icon className="w-8 h-8 text-primary mb-4" />
              <p className="text-3xl font-bold text-foreground">{stat.value}</p>
              <p className="text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Team Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-foreground text-center mb-12">Our Team</h2>
        <p className="text-lg text-muted-foreground text-center max-w-2xl mx-auto">
          Built by experienced professionals from leading tech companies and HR platforms, combining expertise in AI,
          recruitment, and talent management.
        </p>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mb-8">
        <div className="p-12 rounded-2xl bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 border border-border text-center space-y-6">
          <h3 className="text-3xl font-bold text-foreground">Ready to join thousands of successful professionals?</h3>
          <Link
            href="/auth/signup"
            className="inline-flex items-center gap-2 px-8 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Get Started <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </main>
  )
}
