"use client"

import { Button } from "@/components/ui/button"
import {
  ArrowRight,
  Briefcase,
  FileText,
  Zap,
  CheckCircle2,
  Brain,
  Award,
  TrendingUp,
  Lightbulb,
  Target,
} from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"

export default function HomePage() {
  const [activeFeature, setActiveFeature] = useState(0)
  const [scrollPosition, setScrollPosition] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const countries = [
    { name: "United States", href: "#" },
    { name: "Canada", href: "#" },
    { name: "United Kingdom", href: "#" },
    { name: "Australia", href: "#" },
    { name: "Germany", href: "#" },
    { name: "France", href: "#" },
    { name: "India", href: "#" },
    { name: "Singapore", href: "#" },
    { name: "Japan", href: "#" },
    { name: "Brazil", href: "#" },
    { name: "Mexico", href: "#" },
    { name: "UAE", href: "#" },
    { name: "South Africa", href: "#" },
    { name: "New Zealand", href: "#" },
  ]

  const resumeTemplates = [
    "Modern Minimal",
    "Classic Professional",
    "Creative Bold",
    "Executive Premium",
    "Tech Focused",
    "Sales Dynamic",
    "Marketing Creative",
    "Finance Formal",
    "Design Portfolio",
    "Developer Tech",
    "Consultant Elite",
    "Manager Strategic",
    "Startup Fresh",
    "Corporate Clean",
    "Academic Scholar",
    "Artistic Flair",
    "International Global",
    "Minimalist Zen",
    "Colorful Vibrant",
    "Professional Plus",
  ]

  const jobSeekerFeatures = [
    {
      icon: FileText,
      title: "AI Resume Builder",
      description: "Create professional, ATS-optimized resumes in minutes with AI guidance",
      details: ["Smart formatting", "Content suggestions", "Multiple templates", "One-click downloads"],
      color: "from-emerald-400 to-teal-600",
    },
    {
      icon: Zap,
      title: "AI Resume Optimizer",
      description: "Get real-time feedback and optimize your resume for maximum impact",
      details: ["ATS score analysis", "Keyword optimization", "Content improvement", "Performance metrics"],
      color: "from-cyan-400 to-blue-600",
    },
    {
      icon: FileText,
      title: "AI Cover Letter",
      description: "Generate tailored cover letters for every job application",
      details: ["Job-specific content", "Professional tone", "Quick customization", "Export ready"],
      color: "from-pink-400 to-rose-600",
    },
    {
      icon: Brain,
      title: "AI Interview Prep",
      description: "Practice interviews with AI coaching and detailed feedback",
      details: ["Mock interviews", "AI feedback", "Question bank", "Video recording"],
      color: "from-orange-400 to-amber-600",
    },
    {
      icon: TrendingUp,
      title: "AI Career Planning",
      description: "Personalized career roadmap and skill development guidance",
      details: ["Career path analysis", "Skill recommendations", "Progress tracking", "Mentorship"],
      color: "from-red-400 to-pink-600",
    },
    {
      icon: Award,
      title: "AI Goal Setting",
      description: "Set measurable career goals with AI-powered milestones",
      details: ["Goal creation", "Milestone tracking", "Progress analytics", "Achievement rewards"],
      color: "from-indigo-400 to-purple-600",
    },
  ]

  const companyLogos = [
    "Google",
    "Microsoft",
    "Apple",
    "Amazon",
    "Meta",
    "Tesla",
    "Netflix",
    "Adobe",
    "Salesforce",
    "Oracle",
    "IBM",
    "Intel",
    "Cisco",
    "JPMorgan",
    "Goldman Sachs",
    "McKinsey",
    "BCG",
    "Bain",
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Senior Product Manager",
      company: "TechCorp",
      rating: 5,
      text: "TalentFlow helped me land my dream job. The AI Resume Optimizer increased my interviews by 300%!",
      gradient: "from-purple-400 to-pink-600",
    },
    {
      name: "Michael Chen",
      role: "Software Engineer",
      company: "Innovate Inc",
      rating: 5,
      text: "The Interview Prep feature gave me the confidence I needed. Absolutely game-changing!",
      gradient: "from-cyan-400 to-blue-600",
    },
    {
      name: "Emma Davis",
      role: "Marketing Director",
      company: "BrandCo",
      rating: 5,
      text: "Career Planning tool helped me identify the right direction. Worth every penny!",
      gradient: "from-emerald-400 to-teal-600",
    },
    {
      name: "James Wilson",
      role: "Product Designer",
      company: "CreativeStudio",
      rating: 5,
      text: "Landed 5 interviews in one week. The cover letter generator is incredible!",
      gradient: "from-orange-400 to-amber-600",
    },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary via-secondary to-accent rounded-lg flex items-center justify-center animate-pulse-scale">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                TalentFlow
              </span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm hover:text-accent transition duration-300">
                Features
              </a>
              <a href="#products" className="text-sm hover:text-accent transition duration-300">
                Products
              </a>
              <a href="#reviews" className="text-sm hover:text-accent transition duration-300">
                Reviews
              </a>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/auth/login">
                <Button
                  variant="outline"
                  className="hidden sm:inline-flex bg-transparent hover:bg-secondary/10 hover:text-secondary border-secondary"
                >
                  Sign In
                </Button>
              </Link>
              <Link href="/auth/signup">
                <Button className="bg-gradient-to-r from-secondary to-accent hover:opacity-90 text-white shadow-lg shadow-secondary/50 transition-all duration-300">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* 1. HERO SECTION - NATURAL IMAGE DISPLAY */}
      <section className="px-4 sm:px-6 lg:px-8 py-20 md:py-32 bg-gradient-to-br from-background via-primary/5 to-accent/5 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4 animate-float-up">
                <h1 className="text-5xl md:text-6xl font-bold leading-tight text-balance bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                  Land Your Dream Job with AI
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  Unlock your potential with 7 AI-powered tools designed to transform your career journey. From resume
                  optimization to interview prep, we've got you covered.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="#features">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-secondary to-accent hover:opacity-90 text-white shadow-lg shadow-secondary/50"
                  >
                    Explore Features <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-accent hover:bg-accent/10 bg-transparent"
                >
                  Watch Demo
                </Button>
              </div>
              <div className="flex gap-8 pt-8 border-t border-border">
                <div>
                  <p className="text-2xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
                    1M+
                  </p>
                  <p className="text-sm text-muted-foreground">Users Helped</p>
                </div>
                <div>
                  <p className="text-2xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
                    95%
                  </p>
                  <p className="text-sm text-muted-foreground">Success Rate</p>
                </div>
                <div>
                  <p className="text-2xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
                    14
                  </p>
                  <p className="text-sm text-muted-foreground">Countries</p>
                </div>
              </div>
            </div>

            <div className="relative h-full min-h-[500px] flex items-center justify-center overflow-hidden">
              <img
                src="/professional-person-holding-resume-document-confid.jpg"
                alt="Professional with resume"
                className="w-full h-auto object-cover hover:scale-105 transition-transform duration-300 rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 2. TEMPLATES & BUILD YOUR RESUME - 20+ TEMPLATES, PDF EXPORT */}
      <section className="px-4 sm:px-6 lg:px-8 py-20 md:py-32 bg-gradient-to-b from-background to-secondary/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Image */}
            <div className="relative h-full min-h-[450px] flex items-center justify-center order-2 md:order-1 overflow-hidden">
              <img
                src="/resume-templates-showcase-different-layouts.jpg"
                alt="Resume templates"
                className="w-full h-auto object-cover rounded-2xl shadow-2xl hover:scale-105 transition-transform duration-300"
              />
            </div>

            {/* Right Content */}
            <div className="space-y-8 order-1 md:order-2">
              <div className="space-y-4">
                <h2 className="text-5xl md:text-6xl font-bold leading-tight text-balance bg-gradient-to-r from-secondary via-pink-500 to-rose-600 bg-clip-text text-transparent">
                  20+ Professional Templates
                </h2>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  Choose from 20+ professionally designed templates tailored for every industry and career level. Each
                  template is ATS-optimized and ready to use.
                </p>
              </div>

              <div className="space-y-4">
                {[
                  "20+ industry-specific designs",
                  "Real-time preview editor",
                  "ATS-optimized formatting",
                  "Export as PDF instantly",
                  "One-click customization",
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-3 group">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-br from-secondary to-rose-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-lg">{feature}</span>
                  </div>
                ))}
              </div>

              <Link href="/resume-builder">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-secondary to-rose-600 hover:opacity-90 text-white shadow-lg shadow-secondary/50"
                >
                  Start Building Now <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 3. OUR COMPLETE PRODUCT SUITE - EXPANDED */}
      <section
        id="products"
        className="px-4 sm:px-6 lg:px-8 py-20 md:py-32 bg-gradient-to-b from-secondary/5 to-background"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Our Complete Product Suite
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to succeed in your career, from resume building to landing your dream job
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: FileText,
                title: "Resume Builder",
                description: "Create stunning resumes with AI assistance and 20+ templates",
                features: ["AI-powered content", "20+ templates", "PDF export", "ATS-optimized"],
                color: "from-emerald-400 to-teal-600",
              },
              {
                icon: Brain,
                title: "Interview Coach",
                description: "Practice and master interview techniques with AI feedback",
                features: ["Mock interviews", "AI coaching", "Video recording", "Detailed feedback"],
                color: "from-purple-400 to-violet-600",
              },
              {
                icon: Briefcase,
                title: "Career Planner",
                description: "Navigate your career with personalized AI guidance",
                features: ["Career roadmap", "Skill development", "Progress tracking", "Mentorship"],
                color: "from-orange-400 to-amber-600",
              },
              {
                icon: Zap,
                title: "Resume Optimizer",
                description: "Boost your resume with real-time ATS optimization",
                features: ["ATS scoring", "Keyword analysis", "Content tips", "Performance metrics"],
                color: "from-cyan-400 to-blue-600",
              },
              {
                icon: Award,
                title: "Cover Letter Pro",
                description: "Generate tailored cover letters for every application",
                features: ["Job-specific", "Professional tone", "Quick edit", "PDF ready"],
                color: "from-pink-400 to-rose-600",
              },
              {
                icon: Target,
                title: "Goal Achievement",
                description: "Set and track meaningful career milestones",
                features: ["Goal creation", "Milestone tracking", "Analytics", "Rewards"],
                color: "from-indigo-400 to-purple-600",
              },
            ].map((product, idx) => {
              const Icon = product.icon
              return (
                <div
                  key={idx}
                  className="bg-gradient-to-br from-white to-slate-50 dark:from-slate-900 dark:to-slate-800 rounded-2xl p-8 border-2 border-transparent hover:border-accent transition-all duration-300 group cursor-pointer hover:shadow-2xl hover:shadow-accent/20"
                >
                  <div
                    className={`w-14 h-14 bg-gradient-to-br ${product.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:shadow-lg transition-all`}
                  >
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{product.title}</h3>
                  <p className="text-muted-foreground mb-6">{product.description}</p>
                  <div className="space-y-2 mb-6">
                    {product.features.map((feature, fidx) => (
                      <div key={fidx} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent"></div>
                        {feature}
                      </div>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    className="w-full border-accent hover:bg-accent/10 group-hover:border-accent bg-transparent"
                  >
                    Learn More <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* 4. ONE PROFESSIONAL, MULTIPLE RESUMES - CLEARER SHOWCASE */}
      <section className="px-4 sm:px-6 lg:px-8 py-20 md:py-32 bg-gradient-to-b from-background to-accent/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              One Professional, Multiple Resumes
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Tailor your resume for different companies and roles in seconds. Let our AI automatically customize
              content for each opportunity.
            </p>
          </div>

          <div className="relative h-96 md:h-[500px] mb-12">
            <img
              src="/person-with-multiple-different-resume-versions-for.jpg"
              alt="Multiple resumes showcase"
              className="w-full h-full object-cover rounded-3xl shadow-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-3xl flex items-end p-8">
              <div className="text-white space-y-3">
                <h3 className="text-3xl font-bold">Adapt Your Resume for Every Role</h3>
                <p className="text-lg opacity-90 max-w-md">
                  One base resume, multiple versions optimized for Google, Microsoft, Startup, or any company you want
                  to impress.
                </p>
              </div>
            </div>
          </div>

          {/* How it works breakdown */}
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "1", title: "Create Base Resume", desc: "Build your master resume once with all experiences" },
              { step: "2", title: "Add Job Description", desc: "Paste the job posting you're applying for" },
              { step: "3", title: "AI Customizes", desc: "Our AI matches your skills to job requirements" },
              { step: "4", title: "Download & Apply", desc: "Export as PDF and submit immediately" },
            ].map((item, idx) => (
              <div key={idx} className="text-center space-y-4">
                <div className="w-14 h-14 bg-gradient-to-br from-secondary to-accent rounded-full flex items-center justify-center mx-auto">
                  <span className="text-2xl font-bold text-white">{item.step}</span>
                </div>
                <h4 className="font-bold text-lg">{item.title}</h4>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. GET HIRED AT LEADING COMPANIES - WITH FORTUNE 50 LOGOS */}
      <section className="px-4 sm:px-6 lg:px-8 py-20 md:py-28 bg-gradient-to-r from-secondary/10 via-accent/10 to-primary/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Get Hired at Leading Companies
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Land positions at Fortune 500 companies that trust TalentFlow candidates
            </p>
          </div>

          <div className="relative overflow-hidden">
            <div className="flex animate-scroll gap-8 py-6">
              {companyLogos.map((company, idx) => (
                <div
                  key={idx}
                  className="flex-shrink-0 px-6 py-3 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 rounded-xl border border-border hover:border-accent transition-all hover:shadow-lg hover:scale-105 transform duration-300"
                >
                  <p className="font-bold text-base whitespace-nowrap text-center">{company}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 7. DETAILED FEATURE DEEP-DIVES WITH IMAGES */}
      <section className="px-4 sm:px-6 lg:px-8 py-20 md:py-32 bg-gradient-to-b from-background to-secondary/5">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-bold text-center mb-16 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            Master Each Feature
          </h2>

          <div className="space-y-20">
            {jobSeekerFeatures.map((feature, idx) => {
              const Icon = feature.icon
              const isEven = idx % 2 === 0
              return (
                <div key={idx} className="grid md:grid-cols-2 gap-12 items-center">
                  <div className={isEven ? "order-1" : "order-2"}>
                    <img
                      src={`/.jpg?key=rxybe&height=450&width=550&query=${encodeURIComponent(feature.title + " feature interface AI tool")}`}
                      alt={feature.title}
                      className="w-full h-auto rounded-2xl shadow-2xl hover:scale-105 transition-transform duration-300 border-2 border-gradient-to-r from-primary/20 to-accent/20"
                    />
                  </div>

                  <div className={`space-y-6 ${isEven ? "order-2" : "order-1"}`}>
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center flex-shrink-0`}
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-3xl font-bold">{feature.title}</h3>
                        <p className="text-muted-foreground text-sm">{feature.description}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {feature.details.map((detail, didx) => (
                        <div key={didx} className="flex items-start gap-3">
                          <div
                            className={`w-2 h-2 rounded-full bg-gradient-to-r ${feature.color} mt-2 flex-shrink-0`}
                          ></div>
                          <p className="text-lg leading-relaxed">{detail}</p>
                        </div>
                      ))}
                    </div>

                    <Button
                      size="lg"
                      className={`bg-gradient-to-r ${feature.color} hover:opacity-90 text-white shadow-lg`}
                    >
                      Try Now <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* READY TO TRANSFORM YOUR CAREER - MOVED BEFORE FOOTER */}
      <section className="px-4 sm:px-6 lg:px-8 py-12 md:py-16 bg-gradient-to-b from-background to-background">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-secondary via-primary to-accent rounded-3xl p-8 md:p-12 text-center text-white shadow-2xl">
            <Lightbulb className="w-12 h-12 mx-auto mb-4 animate-bounce" />
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Ready to Transform Your Career?</h2>
            <p className="text-base opacity-90 mb-6 max-w-2xl mx-auto">
              Join 1M+ professionals using TalentFlow to land their dream jobs. Start your AI-powered journey today.
            </p>
            <Link href="/auth/signup">
              <Button className="bg-white text-primary hover:bg-white/90 font-bold shadow-lg px-6 py-3 text-base">
                Get Started Today <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 11. FOOTER */}
      <footer className="bg-gradient-to-b from-background to-primary/5 border-t border-accent/20 px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-5 gap-12 mb-16">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-secondary via-accent to-primary rounded-lg flex items-center justify-center">
                  <Briefcase className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  TalentFlow
                </span>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Empowering careers through AI innovation. Your success is our mission.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-bold mb-4 text-lg">Product</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {[
                  { label: "Resume Builder", href: "#" },
                  { label: "AI Optimizer", href: "#" },
                  { label: "Interview Prep", href: "#" },
                  { label: "Career Planning", href: "#" },
                ].map((link, idx) => (
                  <li key={idx}>
                    <Link
                      href={link.href}
                      className="hover:text-accent transition-colors hover:translate-x-1 inline-block"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-bold mb-4 text-lg">Company</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {[
                  { label: "About Us", href: "#" },
                  { label: "Blog", href: "#" },
                  { label: "Careers", href: "#" },
                  { label: "Press", href: "#" },
                ].map((link, idx) => (
                  <li key={idx}>
                    <Link
                      href={link.href}
                      className="hover:text-accent transition-colors hover:translate-x-1 inline-block"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h4 className="font-bold mb-4 text-lg">Resources</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {[
                  { label: "Help Center", href: "#" },
                  { label: "Documentation", href: "#" },
                  { label: "API Reference", href: "#" },
                  { label: "Community", href: "#" },
                ].map((link, idx) => (
                  <li key={idx}>
                    <Link
                      href={link.href}
                      className="hover:text-accent transition-colors hover:translate-x-1 inline-block"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-bold mb-4 text-lg">Legal</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {[
                  { label: "Privacy Policy", href: "#" },
                  { label: "Terms of Service", href: "#" },
                  { label: "Cookie Policy", href: "#" },
                  { label: "Contact", href: "#" },
                ].map((link, idx) => (
                  <li key={idx}>
                    <Link
                      href={link.href}
                      className="hover:text-accent transition-colors hover:translate-x-1 inline-block"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-border my-8"></div>

          {/* Bottom Footer */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-sm text-muted-foreground text-center md:text-left">
              <p>© 2025 TalentFlow. All rights reserved. Made with love for ambitious professionals.</p>
            </div>

            <div className="flex gap-6">
              {[
                { label: "Twitter", icon: "𝕏", href: "#" },
                { label: "LinkedIn", icon: "in", href: "#" },
                { label: "GitHub", icon: "⚙", href: "#" },
              ].map((social, idx) => (
                <Link key={idx} href={social.href}>
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center hover:scale-110 transition-transform hover:shadow-lg">
                    <span className="text-white text-xs font-bold">{social.icon}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
