"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Users, Briefcase, TrendingUp, AlertCircle, BarChart3, Settings, LogOut } from "lucide-react"
import UserMenu from "@/components/user-menu"
import Link from "next/link"

export default function AdminDashboard() {
  const stats = [
    { label: "Total Users", value: "12,459", icon: Users, change: "+12% this month" },
    { label: "Active Jobs", value: "3,842", icon: Briefcase, change: "+28 this week" },
    { label: "Placements", value: "2,156", icon: TrendingUp, change: "+145 this month" },
    { label: "System Health", value: "99.8%", icon: AlertCircle, change: "Optimal" },
  ]

  const recentUsers = [
    { name: "Sarah Johnson", email: "sarah@example.com", role: "Job Seeker", date: "2 hours ago" },
    { name: "Tech Corp Inc", email: "hello@techcorp.com", role: "Employer", date: "5 hours ago" },
    { name: "John Smith", email: "john@recruiters.com", role: "Recruiter", date: "1 day ago" },
    { name: "Stanford University", email: "contact@stanford.edu", role: "University", date: "2 days ago" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">System overview & management</p>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/" className="text-muted-foreground hover:text-foreground transition">
              <LogOut className="w-6 h-6" />
            </Link>
            <UserMenu />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6">
          {stats.map((stat, i) => {
            const Icon = stat.icon
            return (
              <Card
                key={i}
                className="p-6 border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-secondary/5 hover:border-primary/50 transition"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <h3 className="text-3xl font-bold text-foreground mt-2">{stat.value}</h3>
                  </div>
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <p className="text-xs text-muted-foreground">{stat.change}</p>
              </Card>
            )
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* Recent Users */}
          <div className="md:col-span-2">
            <Card className="p-6 border-2 border-border/50">
              <h2 className="text-xl font-bold mb-6">Recent Signups</h2>
              <div className="space-y-4">
                {recentUsers.map((user, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg hover:bg-muted/50 transition"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{user.name}</p>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-primary">{user.role}</p>
                      <p className="text-xs text-muted-foreground">{user.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card className="p-6 border-2 border-border/50 h-fit">
            <h2 className="text-xl font-bold mb-6">Quick Actions</h2>
            <div className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90">
                <Users className="w-4 h-4 mr-2" />
                Manage Users
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-accent to-accent/70 text-accent-foreground hover:opacity-90">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-secondary to-secondary/70 text-secondary-foreground hover:opacity-90">
                <Settings className="w-4 h-4 mr-2" />
                System Settings
              </Button>
            </div>
          </Card>
        </div>

        {/* System Metrics */}
        <Card className="p-6 border-2 border-border/50">
          <h2 className="text-xl font-bold mb-6">System Metrics</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { label: "Server Response Time", value: "45ms", status: "Excellent" },
              { label: "Database Queries", value: "128/sec", status: "Normal" },
              { label: "API Uptime", value: "99.97%", status: "Optimal" },
            ].map((metric, i) => (
              <div key={i} className="p-4 rounded-lg bg-muted/50 border border-border/50">
                <p className="text-sm text-muted-foreground">{metric.label}</p>
                <p className="text-2xl font-bold text-foreground mt-2">{metric.value}</p>
                <p className="text-xs text-primary mt-2">{metric.status}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
