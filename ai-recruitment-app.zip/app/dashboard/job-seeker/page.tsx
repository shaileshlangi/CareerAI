"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  FileText,
  Zap,
  Brain,
  Briefcase,
  Users,
  Sparkles,
  Target,
  TrendingUp,
  ArrowRight,
  CheckCircle2,
} from "lucide-react"
import Link from "next/link"
import UserMenu from "@/components/user-menu"

export default function JobSeekerDashboard() {
  const aiFeatures = [
    {
      icon: FileText,
      title: "AI Resume Builder",
      description: "Create professional, ATS-optimized resumes with AI suggestions",
      color: "from-emerald-400 to-teal-600",
      href: "/tools/resume-builder",
      status: "active",
    },
    {
      icon: Zap,
      title: "AI Resume Optimizer",
      description: "Get real-time feedback and improve your resume score",
      color: "from-cyan-400 to-blue-600",
      href: "/tools/resume-optimizer",
      status: "active",
    },
    {
      icon: Brain,
      title: "AI Cover Letter",
      description: "Generate tailored cover letters for each job application",
      color: "from-purple-400 to-indigo-600",
      href: "/tools/cover-letter",
      status: "active",
    },
    {
      icon: Briefcase,
      title: "AI Job Assistant",
      description: "Smart job matching and personalized recommendations",
      color: "from-orange-400 to-rose-600",
      href: "/tools/job-assistant",
      status: "active",
    },
    {
      icon: Users,
      title: "AI Interview Prep",
      description: "Practice interviews with AI coaching and feedback",
      color: "from-pink-400 to-red-600",
      href: "/tools/interview-prep",
      status: "active",
    },
    {
      icon: Sparkles,
      title: "AI Career Planning",
      description: "Personalized career roadmap and skill development",
      color: "from-yellow-400 to-orange-600",
      href: "/tools/career-planning",
      status: "active",
    },
    {
      icon: Target,
      title: "AI Goal Setting",
      description: "Set measurable goals with AI-powered milestones",
      color: "from-green-400 to-emerald-600",
      href: "/tools/goal-setting",
      status: "active",
    },
  ]

  const recentActivity = [
    { title: "Resume Updated", time: "2 hours ago" },
    { title: "Job Application Sent", time: "Yesterday" },
    { title: "Interview Scheduled", time: "3 days ago" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent">
              Job Seeker Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">Accelerate your career with AI</p>
          </div>
          <UserMenu />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6 border-2 border-emerald-200 dark:border-emerald-800 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Resume Score</p>
                <h3 className="text-3xl font-bold text-emerald-600">85/100</h3>
              </div>
              <TrendingUp className="w-8 h-8 text-emerald-600" />
            </div>
            <p className="text-xs text-muted-foreground">+5 points this week</p>
          </Card>

          <Card className="p-6 border-2 border-cyan-200 dark:border-cyan-800 bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Applications</p>
                <h3 className="text-3xl font-bold text-cyan-600">12</h3>
              </div>
              <Briefcase className="w-8 h-8 text-cyan-600" />
            </div>
            <p className="text-xs text-muted-foreground">3 interviews scheduled</p>
          </Card>

          <Card className="p-6 border-2 border-purple-200 dark:border-purple-800 bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Skills Level</p>
                <h3 className="text-3xl font-bold text-purple-600">Advanced</h3>
              </div>
              <Sparkles className="w-8 h-8 text-purple-600" />
            </div>
            <p className="text-xs text-muted-foreground">7 skills improved</p>
          </Card>
        </div>

        {/* AI Features Grid */}
        <div>
          <div className="mb-8">
            <h2 className="text-3xl font-bold mb-2">AI-Powered Tools</h2>
            <p className="text-muted-foreground">Use our 7 AI tools to advance your career</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {aiFeatures.map((feature, idx) => {
              const Icon = feature.icon
              return (
                <Link key={idx} href={feature.href}>
                  <div className="bg-white dark:bg-slate-900 border-2 border-gray-200 dark:border-gray-700 rounded-2xl p-6 hover:shadow-2xl hover:scale-105 transition-all duration-300 space-y-4 group cursor-pointer h-full">
                    <div
                      className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-lg flex items-center justify-center group-hover:shadow-lg group-hover:shadow-current/50 transition-all`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold mb-1">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">Active</span>
                      <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-accent transition-colors" />
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        </div>

        {/* Recent Activity & Recommendations */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Recent Activity */}
          <Card className="p-6 border-2 border-accent/30">
            <h3 className="text-xl font-bold mb-6">Recent Activity</h3>
            <div className="space-y-4">
              {recentActivity.map((activity, idx) => (
                <div key={idx} className="flex items-start gap-4 pb-4 border-b border-border last:border-0">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">{activity.title}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Next Steps */}
          <Card className="p-6 border-2 border-accent/30 bg-gradient-to-br from-accent/5 to-secondary/5">
            <h3 className="text-xl font-bold mb-6">Recommended Next Steps</h3>
            <div className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-emerald-400 to-teal-600 hover:opacity-90 text-white">
                <Zap className="w-4 h-4 mr-2" />
                Optimize Your Resume
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-purple-400 to-indigo-600 hover:opacity-90 text-white">
                <Brain className="w-4 h-4 mr-2" />
                Practice Interview Questions
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-orange-400 to-rose-600 hover:opacity-90 text-white">
                <Target className="w-4 h-4 mr-2" />
                Set Career Goals
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
