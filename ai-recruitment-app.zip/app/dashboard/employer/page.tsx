"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Briefcase,
  Users,
  TrendingUp,
  FileText,
  BarChart3,
  Settings,
  Plus,
  ArrowRight,
  CheckCircle2,
} from "lucide-react"
import Link from "next/link"
import UserMenu from "@/components/user-menu"

export default function EmployerDashboard() {
  const recentActivity = [
    { title: "Application Received", candidate: "John Smith", position: "Senior Dev", time: "1 hour ago" },
    { title: "Interview Scheduled", candidate: "Sarah Jones", position: "Product Manager", time: "3 hours ago" },
    { title: "Offer Accepted", candidate: "Mike Davis", position: "Designer", time: "1 day ago" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
              Employer Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">Manage your recruitment pipeline</p>
          </div>
          <UserMenu />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="p-6 border-2 border-orange-200 dark:border-orange-800 bg-gradient-to-br from-orange-50 to-rose-50 dark:from-orange-950/30 dark:to-rose-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Open Positions</p>
                <h3 className="text-3xl font-bold text-orange-600">8</h3>
              </div>
              <Briefcase className="w-8 h-8 text-orange-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-br from-pink-50 to-rose-50 dark:from-pink-950/30 dark:to-rose-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Applications</p>
                <h3 className="text-3xl font-bold text-pink-600">247</h3>
              </div>
              <Users className="w-8 h-8 text-pink-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-red-200 dark:border-red-800 bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">In Pipeline</p>
                <h3 className="text-3xl font-bold text-red-600">34</h3>
              </div>
              <TrendingUp className="w-8 h-8 text-red-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-rose-200 dark:border-rose-800 bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-950/30 dark:to-pink-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Interviews</p>
                <h3 className="text-3xl font-bold text-rose-600">12</h3>
              </div>
              <FileText className="w-8 h-8 text-rose-600" />
            </div>
          </Card>
        </div>

        {/* Main Features */}
        <div>
          <div className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-bold mb-2">Recruitment Tools</h2>
              <p className="text-muted-foreground">Manage your hiring process efficiently</p>
            </div>
            <Button className="bg-gradient-to-r from-orange-400 to-rose-600 hover:opacity-90 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Post Job
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-8 border-2 border-orange-200 dark:border-orange-800 bg-gradient-to-br from-orange-50 to-rose-50 dark:from-orange-950/30 dark:to-rose-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-rose-600 rounded-lg flex items-center justify-center mb-4">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Job Posting Manager</h3>
              <p className="text-muted-foreground mb-4">
                Create, manage, and track all your job postings with AI assistance
              </p>
              <Link href="#" className="text-orange-600 hover:text-orange-700 font-medium flex items-center gap-2">
                Manage Jobs <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-br from-pink-50 to-rose-50 dark:from-pink-950/30 dark:to-rose-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-400 to-rose-600 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Candidate Screening</h3>
              <p className="text-muted-foreground mb-4">AI-powered screening to find top candidates automatically</p>
              <Link href="#" className="text-pink-600 hover:text-pink-700 font-medium flex items-center gap-2">
                Screen Candidates <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-red-200 dark:border-red-800 bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-orange-600 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Analytics & Insights</h3>
              <p className="text-muted-foreground mb-4">Track hiring metrics and optimize your recruitment process</p>
              <Link href="#" className="text-red-600 hover:text-red-700 font-medium flex items-center gap-2">
                View Analytics <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-rose-200 dark:border-rose-800 bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-950/30 dark:to-pink-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-600 rounded-lg flex items-center justify-center mb-4">
                <Settings className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Team Management</h3>
              <p className="text-muted-foreground mb-4">Invite team members and manage recruitment workflows</p>
              <Link href="#" className="text-rose-600 hover:text-rose-700 font-medium flex items-center gap-2">
                Manage Team <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>
          </div>
        </div>

        {/* Recent Activity Section */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-6 border-2 border-border/50">
            <h3 className="text-xl font-bold mb-6">Recent Activity</h3>
            <div className="space-y-4">
              {recentActivity.map((activity, idx) => (
                <div key={idx} className="flex items-start gap-4 pb-4 border-b border-border last:border-0">
                  <CheckCircle2 className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-foreground">{activity.title}</p>
                    <p className="text-sm text-muted-foreground">
                      {activity.candidate} - {activity.position}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 border-2 border-orange-200 dark:border-orange-800 bg-gradient-to-br from-orange-50 to-rose-50 dark:from-orange-950/30 dark:to-rose-950/30">
            <h3 className="text-xl font-bold mb-6">Quick Links</h3>
            <div className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-orange-400 to-rose-600 hover:opacity-90 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Post New Job
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-pink-400 to-rose-600 hover:opacity-90 text-white">
                <Users className="w-4 h-4 mr-2" />
                Review Applications
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-red-400 to-orange-600 hover:opacity-90 text-white">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
