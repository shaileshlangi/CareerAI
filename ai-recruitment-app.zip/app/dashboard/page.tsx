"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Briefcase, FileText, Users, TrendingUp } from "lucide-react"
import Link from "next/link"
import UserMenu from "@/components/user-menu"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <UserMenu />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link href="/resume-builder">
            <Card className="p-6 hover:border-accent/50 transition cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="font-bold mb-2">Resume Builder</h3>
              <p className="text-sm text-muted-foreground">Create AI-optimized resumes</p>
            </Card>
          </Link>

          <Link href="/recruitment">
            <Card className="p-6 hover:border-accent/50 transition cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="font-bold mb-2">Recruitment</h3>
              <p className="text-sm text-muted-foreground">Manage candidates & hiring</p>
            </Card>
          </Link>

          <Link href="#">
            <Card className="p-6 hover:border-accent/50 transition cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="font-bold mb-2">Job Applications</h3>
              <p className="text-sm text-muted-foreground">Track your applications</p>
            </Card>
          </Link>

          <Link href="#">
            <Card className="p-6 hover:border-accent/50 transition cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="font-bold mb-2">Analytics</h3>
              <p className="text-sm text-muted-foreground">View your insights</p>
            </Card>
          </Link>
        </div>

        {/* Welcome Section */}
        <Card className="p-8 text-center space-y-4">
          <h2 className="text-3xl font-bold">Welcome to TalentFlow</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Your AI-powered HR and recruitment platform. Get started by building your resume or managing candidates.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/resume-builder">
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Start Building Resume</Button>
            </Link>
            <Link href="/recruitment">
              <Button variant="outline">Go to Recruitment</Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  )
}
