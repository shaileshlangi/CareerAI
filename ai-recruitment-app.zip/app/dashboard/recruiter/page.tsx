"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Users, Database, TrendingUp, Zap, BarChart3, Network, Plus, ArrowRight } from "lucide-react"
import Link from "next/link"
import UserMenu from "@/components/user-menu"

export default function RecruiterDashboard() {
  const recentMatches = [
    { candidate: "Alice Chen", skills: "Python, React, Node.js", match: "95%", time: "2 hours ago" },
    { candidate: "Robert Taylor", skills: "Java, Spring Boot, AWS", match: "88%", time: "5 hours ago" },
    { candidate: "Emma Wilson", skills: "UI/UX, Figma, Adobe XD", match: "92%", time: "1 day ago" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
              Recruiter Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">Streamline your recruitment workflow</p>
          </div>
          <UserMenu />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="p-6 border-2 border-violet-200 dark:border-violet-800 bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-950/30 dark:to-purple-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Active Placements</p>
                <h3 className="text-3xl font-bold text-violet-600">156</h3>
              </div>
              <Users className="w-8 h-8 text-violet-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-purple-200 dark:border-purple-800 bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Database</p>
                <h3 className="text-3xl font-bold text-purple-600">2.5K</h3>
              </div>
              <Database className="w-8 h-8 text-purple-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-indigo-200 dark:border-indigo-800 bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-indigo-950/30 dark:to-blue-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <h3 className="text-3xl font-bold text-indigo-600">92%</h3>
              </div>
              <TrendingUp className="w-8 h-8 text-indigo-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">This Month</p>
                <h3 className="text-3xl font-bold text-blue-600">24</h3>
              </div>
              <Zap className="w-8 h-8 text-blue-600" />
            </div>
          </Card>
        </div>

        {/* Main Features */}
        <div>
          <div className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-bold mb-2">Recruitment Tools</h2>
              <p className="text-muted-foreground">Manage candidates and placements</p>
            </div>
            <Button className="bg-gradient-to-r from-violet-400 to-purple-600 hover:opacity-90 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Add Candidate
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-8 border-2 border-violet-200 dark:border-violet-800 bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-950/30 dark:to-purple-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-violet-400 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                <Database className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Candidate Database</h3>
              <p className="text-muted-foreground mb-4">
                Organize and search through your candidate pool with AI matching
              </p>
              <Link href="#" className="text-violet-600 hover:text-violet-700 font-medium flex items-center gap-2">
                Browse Candidates <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-purple-200 dark:border-purple-800 bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-indigo-600 rounded-lg flex items-center justify-center mb-4">
                <Network className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Pipeline Management</h3>
              <p className="text-muted-foreground mb-4">
                Track candidates through every stage of your placement process
              </p>
              <Link href="#" className="text-purple-600 hover:text-purple-700 font-medium flex items-center gap-2">
                View Pipeline <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-indigo-200 dark:border-indigo-800 bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-indigo-950/30 dark:to-blue-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-400 to-blue-600 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI Matching</h3>
              <p className="text-muted-foreground mb-4">
                Get intelligent candidate-to-job recommendations powered by AI
              </p>
              <Link href="#" className="text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-2">
                Find Matches <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-600 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Performance Analytics</h3>
              <p className="text-muted-foreground mb-4">Monitor placement success and recruitment metrics</p>
              <Link href="#" className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-2">
                View Reports <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>
          </div>
        </div>

        {/* Recent Matches Section */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-6 border-2 border-border/50">
            <h3 className="text-xl font-bold mb-6">Top Matches Today</h3>
            <div className="space-y-4">
              {recentMatches.map((match, idx) => (
                <div
                  key={idx}
                  className="flex items-start justify-between p-4 rounded-lg hover:bg-muted/50 transition border border-border/50"
                >
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{match.candidate}</p>
                    <p className="text-sm text-muted-foreground">{match.skills}</p>
                    <p className="text-xs text-muted-foreground mt-1">{match.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-violet-600">{match.match}</p>
                    <p className="text-xs text-muted-foreground">Match</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 border-2 border-violet-200 dark:border-violet-800 bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-950/30 dark:to-purple-950/30">
            <h3 className="text-xl font-bold mb-6">Placement Tools</h3>
            <div className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-violet-400 to-purple-600 hover:opacity-90 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Add Candidate
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-purple-400 to-indigo-600 hover:opacity-90 text-white">
                <Network className="w-4 h-4 mr-2" />
                View Pipeline
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-indigo-400 to-blue-600 hover:opacity-90 text-white">
                <BarChart3 className="w-4 h-4 mr-2" />
                Performance Report
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
