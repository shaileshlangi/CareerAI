"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  BookOpen,
  Users,
  TrendingUp,
  Briefcase,
  BarChart3,
  Calendar,
  Plus,
  ArrowRight,
  CheckCircle2,
} from "lucide-react"
import Link from "next/link"
import UserMenu from "@/components/user-menu"

export default function UniversityDashboard() {
  const upcomingEvents = [
    { title: "Tech Recruitment Fair", date: "Dec 15, 2024", attendees: "45 companies", status: "Confirmed" },
    { title: "Alumni Networking Webinar", date: "Dec 18, 2024", attendees: "230 students", status: "Confirmed" },
    { title: "Mock Interview Sessions", date: "Dec 22, 2024", attendees: "120 students", status: "Pending" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
              University Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">Connect students with opportunities</p>
          </div>
          <UserMenu />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="p-6 border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Registered Students</p>
                <h3 className="text-3xl font-bold text-blue-600">1.2K</h3>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-cyan-200 dark:border-cyan-800 bg-gradient-to-br from-cyan-50 to-teal-50 dark:from-cyan-950/30 dark:to-teal-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Placements</p>
                <h3 className="text-3xl font-bold text-cyan-600">328</h3>
              </div>
              <TrendingUp className="w-8 h-8 text-cyan-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-teal-200 dark:border-teal-800 bg-gradient-to-br from-teal-50 to-green-50 dark:from-teal-950/30 dark:to-green-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Active Events</p>
                <h3 className="text-3xl font-bold text-teal-600">12</h3>
              </div>
              <Calendar className="w-8 h-8 text-teal-600" />
            </div>
          </Card>

          <Card className="p-6 border-2 border-green-200 dark:border-green-800 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Partner Companies</p>
                <h3 className="text-3xl font-bold text-green-600">87</h3>
              </div>
              <Briefcase className="w-8 h-8 text-green-600" />
            </div>
          </Card>
        </div>

        {/* Main Features */}
        <div>
          <div className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-bold mb-2">University Tools</h2>
              <p className="text-muted-foreground">Manage students, events, and partnerships</p>
            </div>
            <Button className="bg-gradient-to-r from-blue-400 to-cyan-600 hover:opacity-90 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Create Event
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-8 border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-600 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Student Profiles</h3>
              <p className="text-muted-foreground mb-4">
                Manage student data and showcase their qualifications to employers
              </p>
              <Link href="#" className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-2">
                View Students <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-cyan-200 dark:border-cyan-800 bg-gradient-to-br from-cyan-50 to-teal-50 dark:from-cyan-950/30 dark:to-teal-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-teal-600 rounded-lg flex items-center justify-center mb-4">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Career Events</h3>
              <p className="text-muted-foreground mb-4">
                Organize job fairs, webinars, and networking events for students
              </p>
              <Link href="#" className="text-cyan-600 hover:text-cyan-700 font-medium flex items-center gap-2">
                Manage Events <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-teal-200 dark:border-teal-800 bg-gradient-to-br from-teal-50 to-green-50 dark:from-teal-950/30 dark:to-green-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-green-600 rounded-lg flex items-center justify-center mb-4">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Job Board</h3>
              <p className="text-muted-foreground mb-4">
                Dedicated job board for student internships and graduate positions
              </p>
              <Link href="#" className="text-teal-600 hover:text-teal-700 font-medium flex items-center gap-2">
                Browse Jobs <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>

            <Card className="p-8 border-2 border-green-200 dark:border-green-800 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 group hover:shadow-xl hover:scale-105 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-600 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Analytics</h3>
              <p className="text-muted-foreground mb-4">Track student placement rates and employment outcomes</p>
              <Link href="#" className="text-green-600 hover:text-green-700 font-medium flex items-center gap-2">
                View Analytics <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>
          </div>
        </div>

        {/* Upcoming Events Section */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-6 border-2 border-border/50">
            <h3 className="text-xl font-bold mb-6">Upcoming Events</h3>
            <div className="space-y-4">
              {upcomingEvents.map((event, idx) => (
                <div key={idx} className="flex items-start gap-4 pb-4 border-b border-border last:border-0">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{event.title}</p>
                    <p className="text-sm text-muted-foreground">{event.date}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {event.attendees} • {event.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30">
            <h3 className="text-xl font-bold mb-6">Management Tools</h3>
            <div className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-blue-400 to-cyan-600 hover:opacity-90 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Create Event
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-cyan-400 to-teal-600 hover:opacity-90 text-white">
                <Users className="w-4 h-4 mr-2" />
                Manage Students
              </Button>
              <Button className="w-full justify-start bg-gradient-to-r from-teal-400 to-green-600 hover:opacity-90 text-white">
                <BarChart3 className="w-4 h-4 mr-2" />
                Placement Stats
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
