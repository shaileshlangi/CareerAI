"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Briefcase, Users, BookOpen, Building2, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function SigninPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [userType, setUserType] = useState<"job-seeker" | "employer" | "recruiter" | "university" | null>(null)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    try {
      console.log("Login attempt:", { ...formData, userType })
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const redirects: Record<string, string> = {
        "job-seeker": "/dashboard/job-seeker",
        employer: "/dashboard/employer",
        recruiter: "/dashboard/recruiter",
        university: "/dashboard/university",
      }
      window.location.href = redirects[userType!] || "/dashboard"
    } catch (error) {
      console.error("Login error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const roles = [
    { id: "job-seeker", title: "Job Seeker", icon: Briefcase },
    { id: "employer", title: "Employer", icon: Building2 },
    { id: "recruiter", title: "Recruiter", icon: Users },
    { id: "university", title: "University", icon: BookOpen },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
            <Briefcase className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            TalentFlow
          </span>
        </div>

        <Card className="p-8 space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-2xl font-bold">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to your account</p>
          </div>

          {/* Role Selection */}
          <div>
            <p className="text-sm font-medium mb-3">Select your role</p>
            <div className="grid grid-cols-4 gap-2">
              {roles.map((role) => {
                const Icon = role.icon
                return (
                  <button
                    key={role.id}
                    onClick={() => setUserType(role.id as any)}
                    className={`p-3 rounded-lg border-2 transition ${
                      userType === role.id ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                    }`}
                  >
                    <Icon className="w-5 h-5 mx-auto mb-1" />
                    <p className="text-xs font-medium text-center">{role.title.split(" ")[0]}</p>
                  </button>
                )
              })}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Email Address</label>
              <Input
                type="email"
                name="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium">Password</label>
                <Link href="#" className="text-xs text-primary hover:text-primary/80">
                  Forgot password?
                </Link>
              </div>
              <Input
                type="password"
                name="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold gap-2"
              disabled={isLoading || !userType}
            >
              {isLoading ? "Signing in..." : "Sign In"}
              {!isLoading && <ArrowRight className="w-4 h-4" />}
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-card text-muted-foreground">Or continue with</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="w-full bg-transparent">
              Google
            </Button>
            <Button variant="outline" className="w-full bg-transparent">
              LinkedIn
            </Button>
          </div>

          <p className="text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link href="/auth/signup" className="text-primary hover:text-primary/80 font-medium">
              Sign up
            </Link>
          </p>
        </Card>

        <div className="bg-card border border-border rounded-lg p-4 text-center text-sm text-muted-foreground">
          <p className="mb-2 font-medium">Demo Credentials</p>
          <p>Email: demo@talentflow.com</p>
          <p>Password: demo123</p>
        </div>
      </div>
    </div>
  )
}
