"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Briefcase, Users, BookOpen, Building2, ArrowRight, Check } from "lucide-react"
import Link from "next/link"

export default function SignupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [userType, setUserType] = useState<"job-seeker" | "employer" | "recruiter" | "university" | null>(null)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    companyName: "",
    universityName: "",
    phone: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleNext = () => {
    if (userType) setStep(2)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match")
      return
    }

    setIsLoading(true)
    try {
      console.log("Signup attempt:", { ...formData, userType })
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const redirects: Record<string, string> = {
        "job-seeker": "/dashboard/job-seeker",
        employer: "/dashboard/employer",
        recruiter: "/dashboard/recruiter",
        university: "/dashboard/university",
      }
      window.location.href = redirects[userType!] || "/dashboard"
    } catch (error) {
      console.error("Signup error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const roles = [
    {
      id: "job-seeker",
      title: "Job Seeker",
      description: "Build & optimize your resume, find jobs",
      icon: Briefcase,
      color: "from-emerald-400 to-teal-600",
    },
    {
      id: "employer",
      title: "Employer",
      description: "Post jobs & hire talent",
      icon: Building2,
      color: "from-cyan-400 to-blue-600",
    },
    {
      id: "recruiter",
      title: "Recruiter",
      description: "Manage candidates & placements",
      icon: Users,
      color: "from-purple-400 to-indigo-600",
    },
    {
      id: "university",
      title: "University",
      description: "Connect students with opportunities",
      icon: BookOpen,
      color: "from-orange-400 to-rose-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-8">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
            <Briefcase className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            TalentFlow
          </span>
        </div>

        {/* Step Indicator */}
        <div className="flex justify-center gap-2">
          <div className={`w-3 h-3 rounded-full transition ${step === 1 ? "bg-primary" : "bg-border"}`} />
          <div className={`w-3 h-3 rounded-full transition ${step === 2 ? "bg-primary" : "bg-border"}`} />
        </div>

        <Card className="p-8 space-y-6">
          {step === 1 ? (
            <>
              <div className="text-center space-y-2">
                <h1 className="text-3xl font-bold">Choose Your Role</h1>
                <p className="text-muted-foreground">Select what best describes you</p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {roles.map((role) => {
                  const Icon = role.icon
                  return (
                    <button
                      key={role.id}
                      onClick={() => setUserType(role.id as any)}
                      className={`p-6 rounded-xl border-2 transition transform hover:scale-105 ${
                        userType === role.id
                          ? `border-primary bg-gradient-to-br ${role.color} bg-opacity-10`
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <Icon
                        className={`w-8 h-8 mb-3 ${userType === role.id ? "text-primary" : "text-muted-foreground"}`}
                      />
                      <p className="font-semibold text-sm text-foreground">{role.title}</p>
                      <p className="text-xs text-muted-foreground mt-1">{role.description}</p>
                    </button>
                  )
                })}
              </div>

              <Button
                onClick={handleNext}
                disabled={!userType}
                className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold gap-2"
              >
                Continue <ArrowRight className="w-4 h-4" />
              </Button>

              <p className="text-center text-sm text-muted-foreground">
                Already have an account?{" "}
                <Link href="/auth/signin" className="text-primary hover:text-primary/80 font-medium">
                  Sign in
                </Link>
              </p>
            </>
          ) : (
            <>
              <div className="flex items-center gap-4 mb-6">
                <button onClick={() => setStep(1)} className="text-primary hover:text-primary/80 transition">
                  ← Back
                </button>
                <div className="text-center flex-1">
                  <h1 className="text-2xl font-bold">Create Your Account</h1>
                  <p className="text-muted-foreground text-sm">{roles.find((r) => r.id === userType)?.title}</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Full Name</label>
                  <Input
                    type="text"
                    name="fullName"
                    placeholder="John Doe"
                    value={formData.fullName}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Email Address</label>
                  <Input
                    type="email"
                    name="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Phone Number</label>
                  <Input
                    type="tel"
                    name="phone"
                    placeholder="+1 (555) 123-4567"
                    value={formData.phone}
                    onChange={handleChange}
                  />
                </div>

                {userType === "employer" && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Company Name</label>
                    <Input
                      type="text"
                      name="companyName"
                      placeholder="Your Company"
                      value={formData.companyName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                )}

                {userType === "recruiter" && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Recruitment Firm</label>
                    <Input
                      type="text"
                      name="companyName"
                      placeholder="Your Firm Name"
                      value={formData.companyName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                )}

                {userType === "university" && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">University Name</label>
                    <Input
                      type="text"
                      name="universityName"
                      placeholder="Your University"
                      value={formData.universityName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Password</label>
                    <Input
                      type="password"
                      name="password"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Confirm Password</label>
                    <Input
                      type="password"
                      name="confirmPassword"
                      placeholder="••••••••"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                  <p className="text-sm text-foreground">
                    <Check className="w-4 h-4 inline mr-2 text-primary" />
                    Secure account with encrypted credentials
                  </p>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold gap-2"
                  disabled={isLoading}
                >
                  {isLoading ? "Creating account..." : "Create Account"}
                  {!isLoading && <ArrowRight className="w-4 h-4" />}
                </Button>
              </form>

              <p className="text-center text-sm text-muted-foreground">
                Already have an account?{" "}
                <Link href="/auth/signin" className="text-primary hover:text-primary/80 font-medium">
                  Sign in
                </Link>
              </p>
            </>
          )}
        </Card>
      </div>
    </div>
  )
}
