"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Filter } from "lucide-react"
import CandidateList from "@/components/recruitment/candidate-list"
import JobPostings from "@/components/recruitment/job-postings"
import RecruitmentAnalytics from "@/components/recruitment/recruitment-analytics"

export default function RecruitmentPage() {
  const [activeTab, setActiveTab] = useState("candidates")
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")

  // Mock candidates data
  const candidates = [
    {
      id: 1,
      name: "Alex Johnson",
      position: "Senior Developer",
      email: "alex@example.com",
      status: "Interview Scheduled",
      rating: 4.5,
      appliedDate: "2025-11-20",
      resumeScore: 92,
    },
    {
      id: 2,
      name: "Sarah Williams",
      position: "Product Manager",
      email: "sarah@example.com",
      status: "Under Review",
      rating: 4.2,
      appliedDate: "2025-11-18",
      resumeScore: 87,
    },
    {
      id: 3,
      name: "Michael Chen",
      position: "UX Designer",
      email: "michael@example.com",
      status: "Screening",
      rating: 3.8,
      appliedDate: "2025-11-15",
      resumeScore: 78,
    },
    {
      id: 4,
      name: "Emma Davis",
      position: "Data Analyst",
      email: "emma@example.com",
      status: "Rejected",
      rating: 3.0,
      appliedDate: "2025-11-12",
      resumeScore: 65,
    },
  ]

  // Mock jobs data
  const jobs = [
    {
      id: 1,
      title: "Senior Full Stack Developer",
      department: "Engineering",
      location: "San Francisco, CA",
      type: "Full-time",
      posted: "2025-10-15",
      applicants: 24,
      status: "Open",
    },
    {
      id: 2,
      title: "Product Manager",
      department: "Product",
      location: "New York, NY",
      type: "Full-time",
      posted: "2025-10-22",
      applicants: 18,
      status: "Open",
    },
    {
      id: 3,
      title: "UX/UI Designer",
      department: "Design",
      location: "Remote",
      type: "Full-time",
      posted: "2025-11-01",
      applicants: 32,
      status: "Open",
    },
  ]

  const filteredCandidates =
    filterStatus === "all"
      ? candidates.filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
      : candidates.filter((c) => c.status === filterStatus && c.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const stats = {
    totalCandidates: candidates.length,
    interviewScheduled: candidates.filter((c) => c.status === "Interview Scheduled").length,
    underReview: candidates.filter((c) => c.status === "Under Review").length,
    openPositions: jobs.filter((j) => j.status === "Open").length,
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Recruitment Dashboard</h1>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2">
            <Plus className="w-4 h-4" />
            Post Job
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 space-y-2">
            <div className="text-sm text-muted-foreground">Total Candidates</div>
            <div className="text-3xl font-bold">{stats.totalCandidates}</div>
            <div className="text-xs text-accent">In pipeline</div>
          </Card>
          <Card className="p-6 space-y-2">
            <div className="text-sm text-muted-foreground">Interview Scheduled</div>
            <div className="text-3xl font-bold">{stats.interviewScheduled}</div>
            <div className="text-xs text-accent">This week: 2</div>
          </Card>
          <Card className="p-6 space-y-2">
            <div className="text-sm text-muted-foreground">Under Review</div>
            <div className="text-3xl font-bold">{stats.underReview}</div>
            <div className="text-xs text-accent">Pending action</div>
          </Card>
          <Card className="p-6 space-y-2">
            <div className="text-sm text-muted-foreground">Open Positions</div>
            <div className="text-3xl font-bold">{stats.openPositions}</div>
            <div className="text-xs text-accent">Active postings</div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="candidates">Candidates</TabsTrigger>
            <TabsTrigger value="jobs">Job Postings</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Candidates Tab */}
          <TabsContent value="candidates" className="space-y-6 mt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search candidates..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={filterStatus === "all" ? "default" : "outline"}
                  onClick={() => setFilterStatus("all")}
                  className="gap-2"
                >
                  <Filter className="w-4 h-4" />
                  All
                </Button>
                {["Interview Scheduled", "Under Review", "Screening", "Rejected"].map((status) => (
                  <Button
                    key={status}
                    variant={filterStatus === status ? "default" : "outline"}
                    onClick={() => setFilterStatus(status)}
                    size="sm"
                  >
                    {status}
                  </Button>
                ))}
              </div>
            </div>

            <CandidateList candidates={filteredCandidates} />
          </TabsContent>

          {/* Jobs Tab */}
          <TabsContent value="jobs" className="space-y-6 mt-6">
            <JobPostings jobs={jobs} />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6 mt-6">
            <RecruitmentAnalytics candidates={candidates} jobs={jobs} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
