"use client"

import Link from "next/link"
import { ArrowRight, Check } from "lucide-react"

export default function PricingPage() {
  const plans = [
    {
      name: "Starter",
      price: "$0",
      period: "forever free",
      description: "Perfect for getting started",
      features: ["1 Resume", "AI Resume Builder", "Basic templates", "Job matching", "Email support"],
      cta: "Get Started",
      highlighted: false,
    },
    {
      name: "Professional",
      price: "$9.99",
      period: "per month",
      description: "For serious job seekers",
      features: [
        "Unlimited Resumes",
        "AI Resume Optimizer",
        "20+ Templates",
        "Cover Letter Generator",
        "Interview Prep",
        "Priority support",
        "Career Planning",
      ],
      cta: "Start Free Trial",
      highlighted: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "contact us",
      description: "For organizations",
      features: [
        "Everything in Professional",
        "Team management",
        "Analytics dashboard",
        "Custom branding",
        "API access",
        "Dedicated support",
      ],
      cta: "Contact Sales",
      highlighted: false,
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border/50 backdrop-blur-md bg-background/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            TalentFlow
          </div>
          <div className="flex gap-8">
            <Link href="/about" className="text-muted-foreground hover:text-foreground">
              About
            </Link>
            <Link href="/product" className="text-muted-foreground hover:text-foreground">
              Product
            </Link>
            <Link href="/pricing" className="text-foreground font-medium">
              Pricing
            </Link>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground">
              Contact
            </Link>
          </div>
          <Link
            href="/auth/signin"
            className="px-6 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Sign In
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h1 className="text-5xl font-bold text-foreground mb-6">
          Simple, Transparent{" "}
          <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            Pricing
          </span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Choose the perfect plan for your career journey
        </p>
      </section>

      {/* Pricing Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`p-8 rounded-2xl border transition ${
                plan.highlighted
                  ? "border-primary bg-gradient-to-br from-primary/10 to-secondary/10 scale-105 shadow-xl"
                  : "border-border/50 bg-card hover:border-primary/50"
              }`}
            >
              <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
              <p className="text-muted-foreground mb-4">{plan.description}</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                <span className="text-muted-foreground ml-2">{plan.period}</span>
              </div>
              <button
                className={`w-full py-3 rounded-lg font-medium transition mb-8 ${
                  plan.highlighted
                    ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90"
                    : "border border-primary/50 text-primary hover:bg-primary/10"
                }`}
              >
                {plan.cta}
              </button>
              <div className="space-y-3">
                {plan.features.map((feature, j) => (
                  <div key={j} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-foreground text-center mb-12">Frequently Asked Questions</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {[
            { q: "Can I change plans anytime?", a: "Yes, upgrade or downgrade your plan at any time." },
            { q: "Is there a free trial?", a: "Yes, all Professional features come with a 7-day free trial." },
            { q: "What payment methods do you accept?", a: "We accept all major credit cards and payment methods." },
            { q: "Can I cancel anytime?", a: "Yes, cancel your subscription anytime without penalties." },
          ].map((item, i) => (
            <div key={i} className="p-6 rounded-xl border border-border/50 bg-card">
              <h4 className="font-semibold text-foreground mb-2">{item.q}</h4>
              <p className="text-muted-foreground">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mb-8">
        <div className="p-12 rounded-2xl bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 border border-border text-center space-y-6">
          <h3 className="text-3xl font-bold text-foreground">Start your free journey today</h3>
          <Link
            href="/auth/signup"
            className="inline-flex items-center gap-2 px-8 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Get Started <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </main>
  )
}
